# Population Growth Forecasting - Reproducibility Package

This package reproduces the empirical analysis for the manuscript:

**Explainable and Probabilistic Forecasting of Annual Population Growth: A Dynamic Persistence-Correction Machine-Learning Framework**

## Scope

The package reproduces all reported statistical/ML results, SHAP summaries, Monte Carlo probability forecasts, robustness tests, and figures **from the merged analytical dataset supplied by the researcher**. It does not reproduce the upstream extraction and merging of the original World Bank, WHO, IMF, OECD, and V-Dem source files because those source-level extracts and merge scripts were not included in the supplied materials.

## Directory structure

- `data/raw/`: researcher-supplied analytical CSV and variable/source dictionary.
- `data/processed/`: dynamically reconstructed modeling panel used by the scripts.
- `code/run_analysis.py`: end-to-end empirical analysis script.
- `code/build_manuscript.py`: rebuilds the Word manuscript from the generated tables and figures.
- `code/run_all.py`: one-command reproduction of the analysis and Word manuscript.
- `outputs/tables/`: all numeric outputs used in the manuscript.
- `outputs/figures/`: all publication-ready figures used in the manuscript.
- `docs/analysis_protocol.md`: detailed analytic protocol.
- `docs/references.bib`: bibliography used for the manuscript/research design.
- `environment.json`: versions from the verified execution environment.
- `requirements.txt`: pinned Python package versions for reproduction.
- `CHECKSUMS_SHA256.txt`: SHA-256 hashes for package integrity checking.

## Reproduction

Tested with Python 3.13. From the package root:

```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell: .venv\\Scripts\\Activate.ps1

python -m pip install -r requirements.txt
python code/run_all.py
```

`run_all.py` reruns the empirical analysis, recreates the processed panel, CSV tables, figures, `environment.json`, and then rebuilds `docs/PopulationGrowth_Final_Manuscript.docx` before refreshing the SHA-256 checksums. For analysis only, run `python code/run_analysis.py`.

## Analysis design

- Outcome: annual population growth rate at `t+1`.
- Inputs: health, economic, social, political/institutional, and environmental indicators at `t`, plus demographic momentum and first differences.
- Dynamic sample: consecutive `t-1, t, t+1` country-year observations.
- Evaluation: expanding-window rolling-origin out-of-sample forecasts for target years 2016-2020.
- Proposed model: Dynamic Persistence-Correction Gradient Boosting (DPC-GB), which forecasts the change from the current population-growth rate and then adds the predicted correction to the persistence baseline.
- Explainability: out-of-sample SHAP for the correction component plus a structural-only SHAP model using the 20 level predictors.
- Probabilistic prediction: 10,000 empirical Monte Carlo draws per forecast from historical rolling-out-of-sample residuals available before each target year.
- Inference: 10,000-replicate country-cluster bootstrap for the DPC-GB versus persistence forecast-error difference.
- Random seed: 20260817.

## Important data-engineering audit

`d_FreshwaterPC` is excluded from the main dynamic model. Because `FreshwaterPC` is a per-capita quantity, its first difference showed an absolute correlation of approximately 0.992 with current population growth in the dynamically reconstructed panel, creating a serious risk of mechanically re-encoding the target-related population denominator. The level `FreshwaterPC` variable is retained.

## Main verified results

- DPC-GB: MAE 0.133722; RMSE 0.204835; R² 0.933478.
- Persistence: MAE 0.142012; RMSE 0.219197; R² 0.923823.
- DPC-GB RMSE reduction relative to persistence: 6.55%.
- Country-cluster bootstrap RMSE improvement: 0.01436; 95% CI -0.00329 to 0.03742; one-sided p = 0.0861.
- Monte Carlo decline-probability Brier score: 0.01593; ROC-AUC 0.99850; 95% prediction-interval coverage: 0.9701.

The bootstrap interval spans zero; therefore, the manuscript interprets the average improvement as suggestive rather than conventionally statistically significant.

## Reproducibility note

Exact numerical agreement can depend on numerical libraries, operating system, and CPU. The provided seed, pinned package versions, and single-thread settings for key gradient-boosting implementations are intended to minimize such differences.
