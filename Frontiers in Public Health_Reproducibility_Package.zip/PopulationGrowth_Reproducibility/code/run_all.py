#!/usr/bin/env python3
"""Reproduce the analysis outputs and rebuild the Word manuscript."""
from pathlib import Path
import hashlib
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def run(script_name: str) -> None:
    script = ROOT / "code" / script_name
    subprocess.run([sys.executable, str(script)], cwd=ROOT, check=True)


def update_checksums() -> None:
    target = ROOT / "CHECKSUMS_SHA256.txt"
    rows = []
    for p in sorted(ROOT.rglob("*")):
        if p.is_file() and p != target:
            rel = p.relative_to(ROOT).as_posix()
            digest = hashlib.sha256(p.read_bytes()).hexdigest()
            rows.append(f"{digest}  {rel}\n")
    target.write_text("".join(rows), encoding="utf-8")


if __name__ == "__main__":
    run("run_analysis.py")
    run("build_manuscript.py")
    update_checksums()
    print("Reproduction complete.")
    print(ROOT / "docs" / "PopulationGrowth_Final_Manuscript.docx")
