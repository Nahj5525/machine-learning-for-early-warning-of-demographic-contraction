#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from pathlib import Path
import math
import pandas as pd
from docx import Document
from docx.shared import Inches, Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_LINE_SPACING
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parents[1]
TAB = ROOT / 'outputs' / 'tables'
FIG = ROOT / 'outputs' / 'figures'
OUT = ROOT / 'docs' / 'PopulationGrowth_Final_Manuscript.docx'

perf = pd.read_csv(TAB/'model_performance.csv')
yearly = pd.read_csv(TAB/'yearly_model_performance.csv')
prob = pd.read_csv(TAB/'probability_metrics.csv').iloc[0]
boot = pd.read_csv(TAB/'country_cluster_bootstrap.csv')
rob = pd.read_csv(TAB/'robustness.csv')
shapf = pd.read_csv(TAB/'shap_feature_summary.csv')
shapd = pd.read_csv(TAB/'shap_domain_summary.csv')
shaps = pd.read_csv(TAB/'structural_shap_summary.csv')
desc = pd.read_csv(TAB/'descriptive_statistics.csv')
leak = pd.read_csv(TAB/'leakage_audit.csv')
mc = pd.read_csv(TAB/'monte_carlo_predictions.csv')

# ----------------------- helpers -----------------------
def set_cell_shading(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = tcPr.find(qn('w:shd'))
    if shd is None:
        shd = OxmlElement('w:shd')
        tcPr.append(shd)
    shd.set(qn('w:fill'), fill)


def set_cell_margins(cell, top=80, start=80, bottom=80, end=80):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcMar = tcPr.first_child_found_in('w:tcMar')
    if tcMar is None:
        tcMar = OxmlElement('w:tcMar')
        tcPr.append(tcMar)
    for m, v in [('top', top), ('start', start), ('bottom', bottom), ('end', end)]:
        node = tcMar.find(qn('w:' + m))
        if node is None:
            node = OxmlElement('w:' + m)
            tcMar.append(node)
        node.set(qn('w:w'), str(v))
        node.set(qn('w:type'), 'dxa')


def repeat_table_header(row):
    trPr = row._tr.get_or_add_trPr()
    tblHeader = OxmlElement('w:tblHeader')
    tblHeader.set(qn('w:val'), 'true')
    trPr.append(tblHeader)


def prevent_row_split(row):
    trPr = row._tr.get_or_add_trPr()
    cantSplit = OxmlElement('w:cantSplit')
    trPr.append(cantSplit)


def set_run_font(run, name='Times New Roman', size=11, bold=None, italic=None, color=None):
    run.font.name = name
    run._element.get_or_add_rPr().rFonts.set(qn('w:ascii'), name)
    run._element.get_or_add_rPr().rFonts.set(qn('w:hAnsi'), name)
    run._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'), name)
    run.font.size = Pt(size)
    if bold is not None: run.bold = bold
    if italic is not None: run.italic = italic
    if color: run.font.color.rgb = RGBColor(*color)


def add_page_number(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = paragraph.add_run()
    fldChar1 = OxmlElement('w:fldChar'); fldChar1.set(qn('w:fldCharType'), 'begin')
    instrText = OxmlElement('w:instrText'); instrText.set(qn('xml:space'), 'preserve'); instrText.text = ' PAGE '
    fldChar2 = OxmlElement('w:fldChar'); fldChar2.set(qn('w:fldCharType'), 'end')
    run._r.append(fldChar1); run._r.append(instrText); run._r.append(fldChar2)
    set_run_font(run, size=9)


def add_p(doc, text='', style=None, align=None, first_line=True, space_after=5, line=1.15, keep_next=False):
    p = doc.add_paragraph(style=style)
    if text:
        r = p.add_run(text)
        set_run_font(r, size=11)
    if align is not None: p.alignment = align
    pf = p.paragraph_format
    if first_line: pf.first_line_indent = Cm(0.7)
    pf.space_after = Pt(space_after)
    pf.line_spacing = line
    if keep_next: pf.keep_with_next = True
    return p


def add_noindent(doc, text='', bold_lead=None, space_after=5, line=1.15):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(space_after)
    p.paragraph_format.line_spacing = line
    if bold_lead and text.startswith(bold_lead):
        r1 = p.add_run(bold_lead); set_run_font(r1, size=11, bold=True)
        r2 = p.add_run(text[len(bold_lead):]); set_run_font(r2, size=11)
    else:
        r = p.add_run(text); set_run_font(r, size=11)
    return p


def add_heading(doc, text, level=1):
    p = doc.add_paragraph(style=f'Heading {level}')
    p.paragraph_format.space_before = Pt(10 if level == 1 else 7)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.keep_with_next = True
    r = p.add_run(text)
    set_run_font(r, size=13 if level==1 else 11.5, bold=True)
    return p


def add_equation(doc, eq, number=None):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(4); p.paragraph_format.space_after = Pt(4)
    r = p.add_run(eq)
    set_run_font(r, name='Cambria Math', size=11)
    if number:
        r2 = p.add_run('    ' + number); set_run_font(r2, size=10)
    return p


def add_caption(doc, text):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(3); p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.keep_with_next = False
    r = p.add_run(text); set_run_font(r, size=9, italic=True)
    return p


def add_figure(doc, path, caption, width=6.1):
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(4); p.paragraph_format.space_after = Pt(2); p.paragraph_format.keep_with_next = True
    r = p.add_run(); r.add_picture(str(path), width=Inches(width))
    add_caption(doc, caption)


def add_table(doc, headers, rows, widths=None, font_size=8.5, caption=None, note=None):
    if caption:
        p = doc.add_paragraph(); p.paragraph_format.keep_with_next=True; p.paragraph_format.space_after=Pt(3)
        r=p.add_run(caption); set_run_font(r,size=9.5,bold=True)
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = 'Table Grid'
    table.autofit = False
    hdr = table.rows[0]
    repeat_table_header(hdr)
    for j,h in enumerate(headers):
        c=hdr.cells[j]; c.text=str(h); set_cell_shading(c,'D9E2F3'); c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
        set_cell_margins(c)
        if widths: c.width=Inches(widths[j])
        for p in c.paragraphs:
            p.alignment=WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_after=Pt(0)
            for r in p.runs: set_run_font(r,size=font_size,bold=True)
    for row in rows:
        rr=table.add_row(); prevent_row_split(rr)
        for j,val in enumerate(row):
            c=rr.cells[j]; c.text='' if val is None else str(val); c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_margins(c)
            if widths: c.width=Inches(widths[j])
            for p in c.paragraphs:
                p.paragraph_format.space_after=Pt(0); p.paragraph_format.line_spacing=1.0
                if j>0: p.alignment=WD_ALIGN_PARAGRAPH.CENTER
                for r in p.runs: set_run_font(r,size=font_size)
    if note:
        p=doc.add_paragraph(); p.paragraph_format.space_before=Pt(2); p.paragraph_format.space_after=Pt(5)
        r=p.add_run('Note. ' + note); set_run_font(r,size=8.5,italic=True)
    return table


def add_bullet(doc, text, level=0):
    p=doc.add_paragraph(style='List Bullet' if level==0 else 'List Bullet 2')
    p.paragraph_format.space_after=Pt(2); p.paragraph_format.left_indent=Cm(0.6+0.4*level)
    r=p.add_run(text); set_run_font(r,size=10.5)
    return p

# ----------------------- manuscript -----------------------
doc=Document()
sec=doc.sections[0]
sec.top_margin=Cm(2.3); sec.bottom_margin=Cm(2.3); sec.left_margin=Cm(2.35); sec.right_margin=Cm(2.35)
sec.header_distance=Cm(1.1); sec.footer_distance=Cm(1.1)
sec.different_first_page_header_footer=True

# Styles
styles=doc.styles
normal=styles['Normal']; normal.font.name='Times New Roman'; normal._element.rPr.rFonts.set(qn('w:ascii'),'Times New Roman'); normal._element.rPr.rFonts.set(qn('w:hAnsi'),'Times New Roman'); normal.font.size=Pt(11)
for sty in ['Heading 1','Heading 2','Heading 3']:
    s=styles[sty]; s.font.name='Times New Roman'; s._element.rPr.rFonts.set(qn('w:ascii'),'Times New Roman'); s._element.rPr.rFonts.set(qn('w:hAnsi'),'Times New Roman'); s.font.color.rgb=RGBColor(0,0,0)
styles['Heading 1'].font.size=Pt(13); styles['Heading 2'].font.size=Pt(11.5); styles['Heading 3'].font.size=Pt(11)

# Header/footer
hp=sec.header.paragraphs[0]; hp.alignment=WD_ALIGN_PARAGRAPH.RIGHT
r=hp.add_run('Explainable and Probabilistic Population-Growth Forecasting'); set_run_font(r,size=8.5,italic=True,color=(90,90,90))
add_page_number(sec.footer.paragraphs[0])

# Title page
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_before=Pt(42); p.paragraph_format.space_after=Pt(18)
r=p.add_run('Explainable and Probabilistic Forecasting of Annual Population Growth'); set_run_font(r,size=17,bold=True)
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_after=Pt(26)
r=p.add_run('A Dynamic Persistence-Correction Machine-Learning Framework'); set_run_font(r,size=14,bold=True)
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_after=Pt(6)
r=p.add_run('[Blinded for Review]'); set_run_font(r,size=11,italic=True)
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('Original Research Article'); set_run_font(r,size=10)

p=doc.add_paragraph(); p.paragraph_format.space_before=Pt(22); p.paragraph_format.space_after=Pt(4)
r=p.add_run('Abstract'); set_run_font(r,size=12,bold=True)
abstract=(
"Population-growth rates are highly persistent, yet short-run departures from demographic momentum can be associated with changes in fertility, labor-market conditions, health systems, economic performance, institutions, and the environment. This study develops an explainable and probabilistic machine-learning framework for one-year-ahead forecasting of annual population-growth rates across countries. The researcher-assembled complete-case dataset contains 672 country-year observations from 47 countries over 2000-2020 and 20 predictors spanning five substantive domains. Requiring consecutive observations at t-1, t, and t+1 yields a dynamic panel of 522 observations from 45 countries. Forecast performance is assessed using expanding-window rolling-origin out-of-sample tests for 2016-2020 (167 forecasts). The proposed Dynamic Persistence-Correction Gradient Boosting model (DPC-GB) anchors each forecast on the current population-growth rate and uses gradient boosting only to predict the nonlinear correction to persistence. Across the outer test set, DPC-GB achieves MAE=0.1337, RMSE=0.2048, and R²=0.9335, reducing RMSE by 6.55% relative to persistence and outperforming a broad set of linear, kernel, bagging, and boosting benchmarks. Country-cluster bootstrap uncertainty is nevertheless non-negligible: the estimated RMSE improvement is 0.0144 with a 95% percentile interval of -0.0033 to 0.0374. Out-of-sample SHAP analysis shows that demographic momentum dominates the correction forecast, while changes in unemployment and GDP, renewable-energy share, and emissions provide additional predictive information. A structural-only SHAP model identifies hospital-bed availability, fertility, renewable energy, unemployment, and GDP per capita as leading non-demographic predictors. Empirical Monte Carlo simulation converts point forecasts into probabilities of negative population growth and calibrated prediction intervals; the 95% interval covers 97.0% of outer observations. The framework therefore contributes a benchmark-aware, interpretable, and uncertainty-explicit approach to short-horizon demographic forecasting while preserving a clear distinction between predictive attribution and causal explanation."
)
p=doc.add_paragraph(); p.paragraph_format.first_line_indent=Cm(0); p.paragraph_format.space_after=Pt(8); p.paragraph_format.line_spacing=1.08
r=p.add_run(abstract); set_run_font(r,size=10.5)
add_noindent(doc,'Keywords: population growth; machine learning; gradient boosting; SHAP; probabilistic forecasting; Monte Carlo simulation; rolling-origin validation',space_after=2,line=1.0)
add_noindent(doc,'JEL-style themes: demographic forecasting; predictive analytics; public policy; sustainability',space_after=2,line=1.0)

doc.add_page_break()

# 1 Introduction
add_heading(doc,'1. Introduction',1)
intro_paras=[
"Population change is a central input to decisions about public finance, healthcare capacity, education, housing, infrastructure, labor supply, and environmental planning. Even when the long-run demographic path is the principal object of interest, institutions often need reliable short-horizon signals: whether the population-growth rate is likely to accelerate, decelerate, or cross below zero in the next year. Such near-term changes can alter the urgency and sequencing of policy responses. Forecasting annual population growth is therefore related to, but distinct from, projecting the size and age structure of a population over decades.",
"The demographic forecasting literature has developed rigorous stochastic and Bayesian approaches for quantifying uncertainty in fertility, mortality, migration, and total population trajectories. Classic stochastic forecasts emphasized that uncertainty should be represented as a probability distribution rather than by only high, medium, and low scenarios (Lee and Tuljapurkar, 1994). More recent probabilistic projection systems extend this logic across countries and demographic components (Raftery et al., 2012; Raftery et al., 2014; Azose et al., 2016). These approaches are indispensable for long-horizon demographic projection. At the same time, a complementary short-horizon prediction problem arises when researchers possess a high-dimensional cross-country panel of socioeconomic, health, institutional, and environmental indicators and wish to ask whether these variables contain incremental information beyond the strong persistence of recent population growth.",
"Machine-learning methods are attractive for this complementary problem because they can model nonlinearities, interactions, threshold effects, and heterogeneous response surfaces without imposing a single low-dimensional functional form. Prior population-forecasting studies have compared tree ensembles and boosting algorithms with conventional regression or time-series models. For example, Şahinarslan et al. (2021) evaluated XGBoost, CatBoost, linear regression, ridge regression, and time-series approaches using population-related indicators, while Wang et al. (2025) combined XGBoost with metaheuristic optimization and multi-source data for subnational demographic forecasting. These studies demonstrate the predictive potential of machine learning, but three methodological issues remain especially important in cross-country annual-growth forecasting.",
"First, a forecasting model should be evaluated against a genuinely strong benchmark. Annual population-growth rates are persistent. A sophisticated learner can achieve an apparently high R² while still failing to outperform the simple forecast that next year's growth rate will equal the current year's rate. This issue is not cosmetic: if a nonlinear learner cannot beat persistence in a forward-looking validation design, its practical forecasting contribution is limited. Second, black-box accuracy alone is insufficient for policy-facing demographic applications. Users need to know which features changed the forecast and whether the model is relying primarily on demographic momentum or on structural covariates. Third, a point forecast does not answer an operationally salient question such as, 'What is the probability that population growth will be negative next year?' A forecasting framework should therefore characterize predictive uncertainty and evaluate the resulting probabilities and intervals.",
"This study addresses these issues with a Dynamic Persistence-Correction Gradient Boosting model, abbreviated DPC-GB. Rather than asking a machine-learning algorithm to reconstruct the entire population-growth level, DPC-GB begins with the persistence forecast and learns only the correction to that benchmark. Formally, the model predicts the one-year change in the growth rate and adds the predicted correction to the current observed growth rate. This architecture gives the learner a narrower task: explain nonlinear departures from demographic momentum. It also makes the model's SHAP decomposition directly interpretable as forces that push the next-year forecast above or below the persistence anchor.",
"The empirical analysis uses a researcher-assembled country-year dataset spanning 2000-2020. The supplied complete-case file contains 672 observations from 47 countries and 20 predictors organized into health, economic, social, political/institutional, and environmental domains. A dynamic forecasting panel is created by requiring consecutive observations at t-1, t, and t+1, yielding 522 observations from 45 countries. The primary evaluation is deliberately temporal: target years 2016 through 2020 are forecast sequentially using only information available in earlier target years. This expanding-window rolling-origin design produces 167 out-of-sample forecasts and avoids random train-test splitting that would mix future and past observations.",
"The results support the usefulness of the persistence-correction design while also setting appropriate limits on the strength of the conclusion. DPC-GB obtains an out-of-sample RMSE of 0.2048 compared with 0.2192 for persistence, a 6.55% reduction, and it has the lowest aggregate MAE and RMSE among the evaluated models. However, a country-cluster bootstrap yields a 95% interval for the RMSE improvement that includes zero. The improvement should therefore be interpreted as suggestive predictive evidence rather than as a definitive claim of uniform superiority. The stress-year pattern is also informative: excluding 2020 increases the RMSE reduction relative to persistence to approximately 8.44%, whereas all models face a more difficult error environment in 2020.",
"The paper makes four contributions. First, it introduces a benchmark-aware hybrid architecture that preserves demographic persistence while allowing nonlinear structural corrections. Second, it uses out-of-sample SHAP values to distinguish the contribution of demographic momentum from health, economic, social, institutional, and environmental signals. Third, it converts point predictions into empirical Monte Carlo distributions, allowing explicit probabilities of negative population growth and prediction intervals to be evaluated with proper probabilistic metrics. Fourth, it incorporates a data-engineering audit that identifies and removes a mechanically problematic derived variable: the first difference of a per-capita freshwater measure, which almost perfectly re-encodes contemporaneous population movement. Together, these design choices emphasize an important principle for applied machine learning: credible forecasting requires not only model sophistication but also temporally honest validation, strong benchmarks, interpretability, uncertainty quantification, and leakage-aware feature engineering.",
"The remainder of the paper proceeds as follows. Section 2 reviews the relevant literature on probabilistic demographic forecasting, machine learning, and explainability. Section 3 describes the data and sample construction. Section 4 presents the forecasting framework, benchmark models, validation design, SHAP analysis, Monte Carlo procedure, and bootstrap inference. Section 5 reports the empirical results. Section 6 discusses interpretation, policy relevance, limitations, and extensions. Section 7 concludes."
]
for t in intro_paras:add_p(doc,t)

# 2 Literature
add_heading(doc,'2. Literature Review and Conceptual Background',1)
add_heading(doc,'2.1 Probabilistic demographic forecasting and forecast uncertainty',2)
for t in [
"Modern demographic forecasting increasingly treats uncertainty as a primary object rather than an afterthought. Lee and Tuljapurkar (1994) demonstrated the value of stochastic population forecasts that move beyond deterministic scenario bands. Bayesian population-projection research subsequently provided predictive distributions for country-level fertility, mortality, and population trajectories and supported the United Nations' shift toward probabilistic projections (Raftery et al., 2012; Raftery et al., 2014). Migration uncertainty is particularly important because migration can be volatile and difficult to extrapolate; Azose et al. (2016) explicitly incorporated migration uncertainty into probabilistic population projections.",
"The present study does not attempt to replace cohort-component demographic projection. Instead, it addresses an adjacent predictive task: one-year-ahead forecasting of the annual population-growth rate from a multidimensional panel. This distinction matters because long-term population projections depend on age-sex structure and separate component processes, while near-term annual-growth prediction can exploit persistence and contemporaneous structural indicators. The appropriate benchmark and validation design therefore differ from those used in long-horizon projection exercises.",
"Probabilistic evaluation also imposes requirements beyond point accuracy. Brier (1950) provides a proper score for probability forecasts of binary events, while Gneiting and Raftery (2007) emphasize the general importance of proper scoring rules for probabilistic prediction. For a demographic decision maker, a probability that next-year growth will be below zero is often more actionable than a point estimate alone, provided that the probability is calibrated and its uncertainty is transparently described."
]: add_p(doc,t)

add_heading(doc,'2.2 Machine learning for nonlinear population prediction',2)
for t in [
"Machine learning broadens the functional forms available for prediction. Random forests average decorrelated trees to reduce variance (Breiman, 2001), extremely randomized trees increase split randomization (Geurts et al., 2006), gradient boosting sequentially fits learners to residual structure (Friedman, 2001), and modern implementations such as XGBoost, LightGBM, and CatBoost add regularization and computational refinements (Chen and Guestrin, 2016; Ke et al., 2017; Prokhorenkova et al., 2018). Kernel support-vector regression offers a different route to nonlinear prediction (Cortes and Vapnik, 1995). These methods are well suited to tabular panels with correlated predictors, nonlinear interactions, and potentially non-additive relationships.",
"Population applications increasingly exploit these tools. Şahinarslan et al. (2021) show that population forecasting can be formulated as a supervised learning problem using multiple development indicators and machine-learning algorithms. Wang et al. (2025) further demonstrate the use of XGBoost within a hybrid optimization framework for demographic prediction with multi-source information. The central issue, however, is not whether a flexible learner can fit demographic data. The more demanding test is whether it adds incremental out-of-sample value after a strong persistence forecast has already captured the dominant temporal signal.",
"This benchmark logic motivates the DPC-GB design. Residual or correction modeling is conceptually attractive whenever a simple structural or naive forecast is difficult to beat. By learning only the forecast error implied by persistence, a correction model can devote capacity to deviations rather than to reconstructing a highly persistent level. The approach also reduces the temptation to interpret a high R² as proof of incremental predictive value: the proposed model must explicitly lower forecast error relative to persistence."
]: add_p(doc,t)

add_heading(doc,'2.3 Explainability, grouped attribution, and correlated predictors',2)
for t in [
"High-performing tree ensembles are often criticized for opacity. SHAP provides a unified additive feature-attribution framework grounded in Shapley values and assigns a contribution to each feature for each prediction (Lundberg and Lee, 2017). For a correction model, this is especially useful: a positive SHAP value can be read as a feature-level contribution that pushes the learned correction upward, while a negative value pushes it downward, relative to the model's expected correction.",
"Cross-country structural indicators are strongly correlated. GDP per capita and health expenditure, for example, often move together, as can unemployment measures and institutional indices. In such settings, an individual feature's SHAP magnitude should not be interpreted as a causal effect or as an immutable ranking. The present study therefore reports both feature-level SHAP and grouped domain-level SHAP. It also estimates a structural-only model excluding demographic-momentum variables. The dual presentation answers two different questions: what drives the final correction forecast, and which non-demographic structural variables contain predictive signal when the dominant momentum variables are intentionally removed?"
]: add_p(doc,t)

add_heading(doc,'2.4 Research questions and expected empirical contribution',2)
add_noindent(doc,'The empirical analysis is organized around four research questions:',space_after=3)
for b in [
"RQ1. Do nonlinear machine-learning models improve one-year-ahead population-growth forecasts relative to persistence and conventional linear benchmarks?",
"RQ2. Does a persistence-correction architecture outperform direct machine-learning prediction of the growth-rate level?",
"RQ3. Which demographic, health, economic, social, political/institutional, and environmental features account for the model's out-of-sample corrections?",
"RQ4. Can empirical Monte Carlo simulation transform point forecasts into informative and reasonably calibrated probabilities of negative population growth?"
]: add_bullet(doc,b)
add_p(doc,"These questions deliberately separate predictive accuracy from causal explanation. The analysis asks whether variables improve forecasts and how the trained model uses them; it does not claim that changing a SHAP-important variable would cause a corresponding change in population growth.")

# 3 Data
add_heading(doc,'3. Data and Sample Construction',1)
add_heading(doc,'3.1 Researcher-assembled cross-country panel',2)
for t in [
"The empirical dataset supplied for this study is a merged country-year panel covering 2000-2020. The documentation identifies annual population growth as the target and 20 predictors drawn from the World Bank, World Health Organization (WHO), International Monetary Fund (IMF), Organisation for Economic Co-operation and Development (OECD), and V-Dem. The five predictor domains are health, economy, society, politics/institutions, and environment. Several monetary or scale variables were provided as natural logarithms in the assembled analytical file.",
"The sample-construction documentation reports an initial international-statistics pool of 4,616 observations for 2000-2020. Sequential exclusions associated with missing health, economic, social, political, and environmental information result in a complete-case analytical file of 672 country-year observations. This implies substantial complete-case attrition (approximately 85.4% from the documented initial pool), which is an important limitation because the retained countries and years may not be representative of the full international population. The analysis therefore describes the dataset as a cross-country sample rather than as a globally representative panel."
]: add_p(doc,t)

# Table 1 variables
var_rows=[
('Outcome','PopulationGrowth','Annual population growth rate','World Bank'),
('Health','FertilityRate','Total fertility rate','World Bank'),
('Health','HealthExpPC','Log health expenditure per capita (US$)','World Bank'),
('Health','HospitalBeds','Hospital beds per 1,000 people','WHO'),
('Health','DPTImmunization','Infant DPT immunization rate','WHO'),
('Economy','GDPpc','Log GDP per capita, current US$','IMF'),
('Economy','GDPWorldShare','Share of world GDP','IMF'),
('Economy','CPIGrowth','Consumer-price-index growth rate','IMF'),
('Economy','GDPDeflator','Log GDP deflator','IMF'),
('Social','PrimaryExpGDP','Primary education expenditure / GDP','OECD'),
('Social','TertiaryExpGDP','Tertiary education expenditure / GDP','OECD'),
('Social','YouthUnempRate','Youth unemployment rate','World Bank'),
('Social','UnempRate','Unemployment rate','World Bank'),
('Politics','CivilSocietyIndex','Core civil society index (0-1)','V-Dem'),
('Politics','EqualProtection','Equal protection index (0-1)','V-Dem'),
('Politics','FreedomExpression','Freedom of expression / alternative information (0-1)','V-Dem'),
('Politics','AccessJustice','Access to justice for all social groups (0-1)','V-Dem'),
('Environment','RenewEnergyShare','Renewable energy consumption share','World Bank'),
('Environment','FreshwaterPC','Log per-capita renewable internal freshwater resources','World Bank'),
('Environment','GHGEmissions','Log greenhouse-gas emissions','OECD'),
('Environment','AirPollutionExposure','Log annual air-pollution exposure','OECD')]
add_table(doc,['Domain','Variable','Definition in supplied dataset','Source'],var_rows,widths=[0.85,1.25,3.25,0.85],font_size=7.7,caption='Table 1. Variables and source organizations',note='Definitions reproduce or compact the researcher-supplied data dictionary. “Log” denotes variables provided in natural-log form in the analytical file.')

add_heading(doc,'3.2 Descriptive profile',2)
add_p(doc,"Across the 672 complete-case observations, annual population growth averages 0.595 with a standard deviation of 0.843 and ranges from -2.171 to 4.052. The mean fertility rate is 1.698. The political indicators are concentrated toward the upper end of their 0-1 scales in this sample, while economic, health, and environmental measures exhibit substantial cross-country variation. Table 2 reports selected descriptive statistics; the reproducibility package contains the full descriptive table for all variables.")
sel=['PopulationGrowth','FertilityRate','HealthExpPC','HospitalBeds','GDPpc','YouthUnempRate','UnempRate','CivilSocietyIndex','RenewEnergyShare','FreshwaterPC','GHGEmissions']
dd=desc.set_index('Variable').loc[sel].reset_index()
rows=[]
for _,r in dd.iterrows():
    rows.append((r.Variable,f"{r['mean']:.3f}",f"{r['std']:.3f}",f"{r['min']:.3f}",f"{r['median']:.3f}",f"{r['max']:.3f}"))
add_table(doc,['Variable','Mean','SD','Min','Median','Max'],rows,widths=[1.55,.75,.75,.75,.75,.75],font_size=8.2,caption='Table 2. Selected descriptive statistics (complete-case analytical file, N=672)',note='All observations in the supplied analytical file are complete for the displayed variables. Full statistics for all 20 predictors are provided in the reproducibility package.')

add_heading(doc,'3.3 Dynamic forecasting panel and information set',2)
for t in [
"The forecasting problem is defined one year ahead. For each country i and year t, the target is PopulationGrowth(i,t+1). Dynamic features are allowed to use information through year t, including the current growth rate, the previous growth rate, the most recent change in growth, the 20 structural predictors at t, and their first differences from t-1. To ensure that the lag and target refer to adjacent years rather than merely adjacent rows, the sample retains an observation only when the same country is observed at t-1, t, and t+1. This produces 522 dynamic observations from 45 countries, a reduction of 22.3% from the 672 complete-case rows.",
"This construction is intentionally stricter than using all available rows with irregular lags. It makes the temporal meaning of the features uniform across countries. Target years 2016-2020 form the outer evaluation period, producing 167 out-of-sample country-year predictions. Earlier dynamic observations provide the expanding training samples."
]: add_p(doc,t)

add_heading(doc,'3.4 Leakage and mechanical-denominator audit',2)
for t in [
"Feature engineering can introduce target leakage even when raw variables are innocuous. This risk is especially acute for ratios and per-capita measures whose denominator includes population. In the dynamic panel, the first difference of the per-capita freshwater variable, d_FreshwaterPC, has a correlation of -0.9917 with current PopulationGrowth. This near-deterministic relationship is mechanically plausible because changes in a per-capita quantity can reflect movements in its population denominator. Including the derived first difference would therefore allow the learner to recover population movement through a constructed proxy and could exaggerate predictive performance.",
"The main feature set excludes d_FreshwaterPC but retains the level FreshwaterPC. The reproducibility package reports the full correlation audit. This decision illustrates a broader principle: predictive pipelines should audit derived ratios and per-capita transformations for mechanical relationships before treating them as independent covariates."
]: add_p(doc,t)

# 4 Methods
add_heading(doc,'4. Methods',1)
add_heading(doc,'4.1 Forecasting target and persistence benchmark',2)
add_p(doc,"Let G(i,t) denote the annual population-growth rate for country i in year t. The task is to forecast G(i,t+1) using information available no later than t. The natural persistence benchmark is:")
add_equation(doc,'Ĝᵖ(i,t+1) = G(i,t)', '(1)')
add_p(doc,"Because annual population growth exhibits substantial short-run inertia, equation (1) is a demanding benchmark. Any proposed nonlinear model is evaluated on its ability to reduce forecast error relative to this anchor, not merely on its absolute R².")

add_heading(doc,'4.2 Direct benchmark models',2)
add_p(doc,"The comparison set covers linear, penalized, kernel, bagging, and boosting approaches: ordinary least squares (OLS), ridge, elastic net, radial-basis support-vector regression, random forest, extremely randomized trees, gradient boosting, histogram gradient boosting, XGBoost, LightGBM, and CatBoost. Linear and support-vector models are estimated within standardized pipelines. Tree-based models use fixed, parsimonious hyperparameters, documented in Appendix B and the analysis script. The fixed configurations are intentional: the sample is modest, and repeatedly tuning hyperparameters against the limited outer period would risk turning the test years into a model-selection device.")

add_heading(doc,'4.3 Proposed Dynamic Persistence-Correction Gradient Boosting',2)
add_p(doc,"The proposed model reframes the problem around the change from persistence. Define the correction target as:")
add_equation(doc,'ΔG(i,t+1) = G(i,t+1) − G(i,t).', '(2)')
add_p(doc,"A gradient-boosting regressor estimates the correction using the dynamic information set Z(i,t):")
add_equation(doc,'ΔĜ(i,t+1) = f_GB[Z(i,t)].', '(3)')
add_p(doc,"The final DPC-GB forecast is then:")
add_equation(doc,'Ĝᴰᴾᶜ(i,t+1) = G(i,t) + ΔĜ(i,t+1).', '(4)')
for t in [
"The architecture can be viewed as a nonlinear error-correction layer on top of the demographic persistence benchmark. If the learner detects no systematic departure, the correction approaches zero and the forecast remains close to persistence. When structural and momentum features indicate acceleration or deceleration, the correction moves the forecast accordingly. This design is especially appropriate when the naive benchmark already explains most short-run variation.",
"The DPC-GB correction learner uses 80 gradient-boosting stages, maximum depth 2, learning rate 0.05, Huber loss, and random seed 20260817. A DPC-XGBoost model with the same persistence-correction logic is estimated as a robustness alternative."
]: add_p(doc,t)

add_heading(doc,'4.4 Rolling-origin out-of-sample validation',2)
for t in [
"Forecast evaluation follows an expanding-window rolling-origin design. For target year 2016, the model is trained only on dynamic observations with target years before 2016 and evaluated on all available 2016 country targets. The training window is then expanded and the procedure is repeated for 2017, 2018, 2019, and 2020. No model for a target year is fitted using observations whose target occurs in that year or later.",
"This temporal separation is central to the credibility of the exercise. Random row-level splitting can place later observations for a country in the training data while evaluating earlier observations in the test data, inflating the apparent ability to generalize forward in time. Rolling-origin evaluation instead mirrors the intended use case: predicting the next year from the past. The primary aggregate metrics are mean absolute error (MAE), root mean squared error (RMSE), and R². MAE and RMSE provide complementary views because RMSE penalizes large misses more strongly; forecast accuracy should not be judged from R² alone (Hyndman and Koehler, 2006)."
]: add_p(doc,t)

add_heading(doc,'4.5 Out-of-sample SHAP and domain aggregation',2)
for t in [
"For each outer target year, SHAP values are computed on that year's held-out observations using only the corresponding fitted DPC-GB correction learner. This produces a genuinely out-of-sample explanation set rather than explanations of the training sample. Because the final forecast in equation (4) equals persistence plus a learned correction, the SHAP values describe the features responsible for upward or downward adjustments relative to persistence.",
"Absolute SHAP values are averaged across the 167 outer observations to produce global feature importance. To reduce over-interpretation of correlated individual features, contributions are also summed within six groups: demographic momentum, health, economy, society, politics/institutions, and environment. The demographic-momentum group contains current population growth, the lagged growth level, and the most recent change in growth.",
"A second SHAP analysis estimates a structural-only gradient-boosting model from the 20 level predictors, excluding all demographic-momentum features and first differences. This model is not presented as the best forecasting model. Its purpose is interpretive: it shows which non-demographic variables carry the greatest predictive signal when the dominant autoregressive information is deliberately withheld."
]: add_p(doc,t)

add_heading(doc,'4.6 Empirical Monte Carlo predictive distributions',2)
for t in [
"Point forecasts are converted into predictive distributions by adding empirical historical out-of-sample residuals to the DPC-GB point prediction. For each target year, the residual pool is constructed using rolling out-of-sample DPC-GB errors from earlier target years contained within that target year's training information. This avoids using future test residuals to characterize past uncertainty. For each forecast, 10,000 residuals are drawn with replacement and added to the point forecast.",
"The simulations yield the estimated probability P[G(i,t+1)<0], a 90% prediction interval, and a 95% prediction interval. The negative-growth probability is evaluated against the realized binary event using the Brier score, ROC-AUC, and average precision. Interval performance is summarized by empirical coverage and average interval width. This residual-bootstrap Monte Carlo procedure is intentionally transparent; it represents empirical forecast uncertainty rather than a fully specified structural demographic probability model."
]: add_p(doc,t)

add_heading(doc,'4.7 Country-cluster bootstrap and robustness',2)
for t in [
"The 167 outer predictions include repeated observations for some countries. To assess uncertainty in the aggregate forecast improvement without pretending that country-year errors are independent, a country-cluster bootstrap resamples countries with replacement. For each of 10,000 bootstrap samples, RMSE and MAE are recomputed for persistence and DPC-GB, and their difference is stored. Percentile intervals and a one-sided empirical probability that the improvement is non-positive are reported.",
"Robustness checks include the alternative DPC-XGBoost correction learner, direct machine-learning models, a structural-only model, and a re-estimation of aggregate performance excluding target year 2020. The 2020 exclusion is not used to improve the primary result; it is a stress-test diagnostic because pandemic-era demographic dynamics and mobility created an unusually difficult forecasting environment."
]: add_p(doc,t)

# 5 Results
add_heading(doc,'5. Results',1)
add_heading(doc,'5.1 Aggregate point-forecast performance',2)
proposed=perf[perf.Model=='DPC-GB (proposed)'].iloc[0]; pers=perf[perf.Model=='Persistence'].iloc[0]
add_p(doc,f"Table 3 compares aggregate rolling-origin out-of-sample performance. DPC-GB is the best model on both MAE and RMSE, with MAE={proposed.MAE:.4f}, RMSE={proposed.RMSE:.4f}, and R²={proposed.R2:.4f}. The persistence benchmark achieves MAE={pers.MAE:.4f}, RMSE={pers.RMSE:.4f}, and R²={pers.R2:.4f}. DPC-GB therefore reduces MAE by {100*(1-proposed.MAE/pers.MAE):.2f}% and RMSE by {100*(1-proposed.RMSE/pers.RMSE):.2f}% relative to persistence. DPC-XGBoost also improves on persistence, but by a smaller margin. None of the direct machine-learning models beats DPC-GB in aggregate RMSE.")
# model table top 11 + linear
model_order=['DPC-GB (proposed)','DPC-XGBoost','Persistence','RandomForest','XGBoost','GradientBoosting','ExtraTrees','LightGBM','CatBoost','ElasticNet','Ridge','OLS','SVR-RBF']
rows=[]
for m in model_order:
    r=perf[perf.Model==m].iloc[0]
    rows.append((m,f"{r.MAE:.4f}",f"{r.RMSE:.4f}",f"{r.R2:.4f}",f"{r.RMSE_Improvement_pct:+.2f}%"))
add_table(doc,['Model','MAE','RMSE','R²','RMSE gain vs. persistence'],rows,widths=[2.25,.75,.75,.75,1.25],font_size=8.2,caption='Table 3. Rolling-origin out-of-sample forecast performance, 2016-2020',note='N=167 for every displayed model. Positive RMSE gain indicates lower RMSE than persistence. Hyperparameters are fixed ex ante for this analysis and are reported in Appendix B.')
add_figure(doc,FIG/'fig1_model_rmse.png','Figure 1. Aggregate rolling-origin out-of-sample RMSE across forecast models.',width=5.9)

add_heading(doc,'5.2 Performance by target year and the 2020 stress test',2)
for t in [
"Aggregate performance masks meaningful year-to-year heterogeneity. Persistence is the strongest of the highlighted models in 2016 (RMSE 0.1278), whereas DPC-GB performs particularly well in 2017, 2018, and 2019. In 2020, errors rise sharply across models. DPC-XGBoost obtains the lowest RMSE among the two correction models in that year, while the direct Gradient Boosting model is slightly lower still; nevertheless, all 2020 RMSE values are far above their pre-2020 levels.",
"This pattern reinforces two points. First, the proposed hybrid is not a claim of mechanical dominance in every period. Its advantage is an aggregate reduction in error across a demanding forward-validation sequence. Second, structural breaks can overwhelm relationships learned from historical panels. When 2020 is excluded, DPC-GB RMSE falls to 0.1647 versus 0.1799 for persistence, an 8.44% reduction. The primary specification retains 2020 precisely because forecast systems should be assessed under difficult as well as favorable conditions."
]: add_p(doc,t)
# Year table only key models
rows=[]
for y in [2016,2017,2018,2019,2020]:
    vals=[]
    for m in ['Persistence','GradientBoosting','XGBoost','DPC-GB (proposed)','DPC-XGBoost']:
        z=yearly[(yearly.TargetYear==y)&(yearly.Model==m)].iloc[0]
        vals.append(f"{z.RMSE:.4f}")
    rows.append((str(y),*vals))
add_table(doc,['Year','Persistence','Direct GB','Direct XGB','DPC-GB','DPC-XGB'],rows,widths=[.7,1.05,1.05,1.05,1.05,1.05],font_size=8.2,caption='Table 4. RMSE by outer target year',note='Each target year is forecast from an expanding training window containing only earlier target years.')
add_figure(doc,FIG/'fig2_yearly_rmse.png','Figure 2. Rolling-origin RMSE by target year for selected models.',width=5.9)

add_heading(doc,'5.3 What changes the persistence forecast? Out-of-sample SHAP evidence',2)
top=shapf.head(8)
add_p(doc,"The DPC-GB SHAP analysis explains the correction component, not the total population-growth level. The largest mean absolute attribution belongs to the recent change in population growth (d_PopulationGrowth), followed by the earlier growth level (PG_lag2), the change in unemployment, current population growth, and the change in GDP per capita. This ordering is substantively coherent with the architecture: the model mostly uses demographic momentum to determine whether persistence should be adjusted, but labor-market and macroeconomic changes contribute to the magnitude and direction of that adjustment.")
add_p(doc,"Grouped SHAP attribution strengthens this interpretation. Demographic momentum has mean summed absolute SHAP of 0.0480, substantially larger than the social (0.0169), economic (0.0104), environmental (0.0098), health (0.0032), and political/institutional (0.0007) groups. The result should not be read as evidence that institutional or health variables are unimportant for long-run demography. It means that, conditional on recent population-growth dynamics and the other available variables, they contribute less to this particular one-year correction forecast in the retained sample.")
rows=[]
for _,r in shapf.head(10).iterrows(): rows.append((r.Feature,f"{r.MeanAbsSHAP:.5f}",f"{r.MeanSHAP:+.5f}"))
add_table(doc,['Feature','Mean |SHAP|','Mean SHAP'],rows,widths=[3.3,1.3,1.3],font_size=8.4,caption='Table 5A. Leading out-of-sample SHAP contributions to the DPC-GB correction',note='SHAP is calculated on each held-out outer target year. Mean SHAP indicates average signed contribution to the learned correction; it is not a causal effect.')
rows=[]
for _,r in shapd.iterrows(): rows.append((r.Domain,f"{r.MeanSumAbsSHAP:.5f}"))
add_table(doc,['Domain','Mean summed |SHAP|'],rows,widths=[3.8,2.0],font_size=8.5,caption='Table 5B. Grouped out-of-sample SHAP importance',note='Domain contributions are summed within each country-year before averaging across the outer test set.')
add_figure(doc,FIG/'fig3_shap_features.png','Figure 3. Leading out-of-sample SHAP importances for the DPC-GB correction component.',width=5.9)
add_figure(doc,FIG/'fig4_shap_domains.png','Figure 4. Grouped out-of-sample SHAP importance by substantive domain.',width=5.65)

add_heading(doc,'5.4 Structural-only predictor importance',2)
add_p(doc,"The structural-only model intentionally removes demographic momentum and first-difference features. Its forecast performance is materially weaker (MAE 0.3597, RMSE 0.4582, R² 0.6672), confirming that recent population-growth dynamics contain information that the structural indicators cannot replace. Nevertheless, the structural SHAP ranking is informative. Hospital-bed availability has the largest mean absolute SHAP, followed by fertility, renewable-energy share, overall unemployment, youth unemployment, GDP per capita, per-capita freshwater resources, and health expenditure per capita. EqualProtection receives zero importance in this fitted structural-only model, consistent with its limited variation in the retained sample.")
add_p(doc,"These rankings are best interpreted as predictive associations conditional on the sample and feature set. Hospital beds, for example, may proxy broader development, age structure, health-system capacity, or other correlated characteristics; a high SHAP magnitude does not establish a demographic causal mechanism. The structural-only analysis is included to reveal residual information content, not to rank policy levers.")
rows=[]
for _,r in shaps.head(10).iterrows(): rows.append((r.Feature,f"{r.MeanAbsSHAP:.4f}",f"{r.MeanSHAP:+.4f}"))
add_table(doc,['Structural feature','Mean |SHAP|','Mean SHAP'],rows,widths=[3.3,1.3,1.3],font_size=8.4,caption='Table 5C. Structural-only SHAP ranking',note='The structural-only model uses the 20 level predictors and excludes demographic momentum. Its aggregate RMSE is 0.4582, so this table is interpretive rather than a recommendation to replace the main forecasting model.')

add_heading(doc,'5.5 Monte Carlo probabilities of negative population growth',2)
add_p(doc,f"The empirical Monte Carlo procedure generates 10,000 simulated outcomes for each of the 167 outer forecasts. There are {int(prob.NegativeEvents)} realized negative-growth events. The probability forecasts obtain a Brier score of {prob.BrierScore:.4f}, ROC-AUC of {prob.ROC_AUC:.4f}, and average precision of {prob.AveragePrecision:.4f}. The nominal 90% interval covers {100*prob.PI90_Coverage:.1f}% of realized outcomes and the 95% interval covers {100*prob.PI95_Coverage:.1f}%, with mean widths of {prob.Mean_PI90_Width:.3f} and {prob.Mean_PI95_Width:.3f}, respectively.")
add_p(doc,"The discrimination metrics are exceptionally high, but they require cautious interpretation. Only 29 negative-growth events occur in the outer evaluation sample, and the same strong demographic persistence that makes point forecasting feasible also makes the sign of growth relatively stable in many countries. The probability system is therefore promising but should be tested on larger and more geographically diverse samples before its classification performance is generalized.")
# selected 2020 risk English translation
name_map={'불가리아':'Bulgaria','라트비아':'Latvia','우크라이나':'Ukraine','루마니아':'Romania','이탈리아':'Italy','헝가리':'Hungary','폴란드':'Poland','포르투갈':'Portugal','핀란드':'Finland','독일':'Germany','대한민국':'South Korea'}
z=mc[mc.TargetYear==2020].sort_values('P_negative',ascending=False)
selected=[]
for kr in ['불가리아','라트비아','우크라이나','루마니아','이탈리아','헝가리','폴란드','포르투갈','핀란드','독일','대한민국']:
    if (z.Country==kr).any():
        r=z[z.Country==kr].iloc[0]
        selected.append((name_map[kr],f"{r.y_true:.3f}",f"{r.PointForecast:.3f}",f"{100*r.P_negative:.1f}%",f"[{r.PI95_L:.3f}, {r.PI95_U:.3f}]"))
add_table(doc,['Country','Observed','Point forecast','P(growth<0)','95% PI'],selected,widths=[1.3,.9,1.15,1.15,1.55],font_size=8.0,caption='Table 6. Illustrative 2020 out-of-sample decline probabilities',note='The selected countries illustrate both successful high-risk identification and tail-risk misses. Poland, for example, experienced a much sharper decline than the point forecast anticipated, underscoring structural-break risk.')
add_figure(doc,FIG/'fig5_probability_calibration.png','Figure 5. Calibration of Monte Carlo probabilities for the negative-growth event.',width=4.85)
add_figure(doc,FIG/'fig7_predicted_vs_observed.png','Figure 6. Observed versus DPC-GB rolling-origin out-of-sample point forecasts.',width=4.95)

add_heading(doc,'5.6 Bootstrap uncertainty and robustness',2)
br=boot[boot.Metric.str.startswith('RMSE')].iloc[0]; ba=boot[boot.Metric.str.startswith('MAE')].iloc[0]
add_p(doc,f"The country-cluster bootstrap tempers the aggregate ranking. The estimated RMSE improvement of persistence minus DPC-GB is {br.Estimate:.4f}; its 95% percentile interval is [{br['CI2.5']:.4f}, {br['CI97.5']:.4f}] and the one-sided empirical probability of a non-positive improvement is {br.OneSided_p:.4f}. For MAE, the improvement is {ba.Estimate:.4f}, the 95% interval is [{ba['CI2.5']:.4f}, {ba['CI97.5']:.4f}], and the one-sided probability is {ba.OneSided_p:.4f}. Because both intervals include zero, the evidence does not support a conventional 5% significance claim that DPC-GB uniformly dominates persistence across the country population represented by the sample.")
add_p(doc,"The alternative DPC-XGBoost model nonetheless produces a 4.04% RMSE reduction relative to persistence, suggesting that the persistence-correction concept is not unique to a single correction learner. Excluding the 2020 stress year strengthens DPC-GB's relative performance: RMSE is 0.1647 versus 0.1799 for persistence, an 8.44% reduction. Taken together, the results support the architecture as a useful predictive strategy while also showing that sample size, cross-country heterogeneity, and shock years materially affect inference about forecast superiority.")
rows=[
('RMSE improvement: Persistence - DPC-GB',f"{br.Estimate:.4f}",f"[{br['CI2.5']:.4f}, {br['CI97.5']:.4f}]",f"{br.OneSided_p:.4f}"),
('MAE improvement: Persistence - DPC-GB',f"{ba.Estimate:.4f}",f"[{ba['CI2.5']:.4f}, {ba['CI97.5']:.4f}]",f"{ba.OneSided_p:.4f}"),
('Pre-2020 DPC-GB RMSE','0.1647','Persistence=0.1799','8.44% lower'),
('DPC-XGBoost full-sample RMSE','0.2104','Persistence=0.2192','4.04% lower')]
add_table(doc,['Robustness quantity','Estimate','Comparison / 95% interval','Interpretation'],rows,widths=[2.45,1.0,1.65,1.25],font_size=7.9,caption='Table 7. Forecast-improvement uncertainty and selected robustness results',note='Bootstrap resampling is at the country level with 10,000 replicates. The reported one-sided probability is the share of bootstrap improvements that are non-positive.')

# 6 Discussion
add_heading(doc,'6. Discussion',1)
add_heading(doc,'6.1 Why persistence-correction works in this setting',2)
for t in [
"The central empirical finding is not that a generic machine-learning model dramatically transforms population forecasting. Rather, it is that a carefully structured learner can add modest incremental value to an already strong demographic persistence signal. Direct boosting, random forests, and other flexible models obtain high R² values, yet several do not beat persistence on RMSE. The proposed model improves the task formulation by asking machine learning to predict only what persistence misses.",
"This division of labor has statistical and substantive advantages. Statistically, the correction target is closer to a stationary deviation than the growth-rate level and reduces the burden on the learner to reproduce persistent cross-country differences. Substantively, it respects demographic inertia: absent strong information to the contrary, next-year growth remains anchored near current growth. The correction learner becomes responsible for identifying accelerations and decelerations associated with recent demographic changes and structural conditions.",
"The SHAP results are consistent with this interpretation. The recent change in population growth and the earlier growth level dominate the correction. The change in unemployment is the strongest structural/dynamic feature, and changes in GDP per capita also matter. These patterns suggest that year-to-year revisions are driven primarily by demographic trajectory, with economic and labor-market information refining the forecast rather than replacing the trajectory."
]: add_p(doc,t)

add_heading(doc,'6.2 Substantive interpretation of structural signals',2)
for t in [
"The structural-only SHAP results place hospital beds and fertility at the top of the non-demographic ranking. Fertility has a direct conceptual connection to population change, although its short-run relationship with total population growth depends on the age structure, mortality, and migration. Hospital-bed availability is less direct and should be viewed as a broad development and health-system signal. Renewable-energy share, unemployment, GDP per capita, freshwater resources, and health expenditure also carry predictive information in the structural-only model.",
"The difference between structural-only SHAP and full DPC-GB SHAP is informative. A variable can be important for cross-sectional prediction of population-growth levels while contributing little to a one-year correction after recent growth history is known. This distinction prevents a common interpretive mistake: treating variables that explain level differences across countries as if they necessarily forecast short-run changes. For policy analysis, the two questions should be kept separate."
]: add_p(doc,t)

add_heading(doc,'6.3 From point forecasts to actionable risk probabilities',2)
for t in [
"The Monte Carlo layer changes the output from a single number to a distribution. This is useful because the sign of population growth is often operationally meaningful. Local governments, universities, hospitals, employers, and pension systems may respond differently when population decline is merely possible versus highly probable. A probability forecast allows that distinction to be expressed directly.",
"The 2020 examples also show why probabilities should not be mistaken for certainty. The model assigns high decline probabilities to several countries that subsequently experienced negative growth, but it underestimates the severity of some abrupt outcomes, notably Poland in the illustrative table. An empirical residual distribution is constrained by the history it has seen. When a new shock changes migration, mortality, or administrative measurement in ways not represented in past residuals, both point and interval forecasts can be wrong. Probabilistic output improves decision support, but it does not eliminate structural-break risk."
]: add_p(doc,t)

add_heading(doc,'6.4 Methodological implications for machine-learning forecast studies',2)
for t in [
"Several methodological lessons generalize beyond demography. First, the benchmark should reflect the hardest simple alternative. In persistent processes, persistence can be a more informative benchmark than OLS. Second, validation must respect time. An impressive random-split result can be irrelevant to genuine forecasting if later observations leak into training. Third, explainability should be aligned with model architecture. In DPC-GB, SHAP naturally explains departures from persistence, which is more policy-interpretable than explaining an opaque level forecast. Fourth, probabilistic forecasts should be scored, not merely visualized. Finally, feature engineering must be audited for mathematical relationships with the target, particularly when variables are ratios, shares, or per-capita quantities.",
"The d_FreshwaterPC audit is an important example. A conventional automated pipeline could have retained this engineered feature because its predictive signal is extremely strong. That very strength is a warning sign. The near-perfect correlation with population growth is plausibly generated by the denominator construction rather than by a substantively independent environmental mechanism. Excluding the feature reduces headline accuracy relative to what a leakage-prone specification could report, but increases the credibility of the analysis."
]: add_p(doc,t)

add_heading(doc,'6.5 Limitations and future research',2)
limitations=[
"Sample selection. The documented complete-case filter reduces an initial pool of 4,616 observations to 672. The resulting 45-country dynamic panel is not globally representative, and the pattern of missingness may be related to development, institutional capacity, or statistical-system quality.",
"Forecast horizon. The study focuses on one-year-ahead growth-rate forecasts. Performance at three-, five-, or ten-year horizons may differ substantially, and persistence is likely to weaken as the horizon lengthens.",
"Demographic structure. The dataset does not explicitly model age-sex cohorts or separately project births, deaths, and migration. DPC-GB is therefore complementary to, not a replacement for, cohort-component and probabilistic demographic projection systems.",
"Causal interpretation. SHAP explains predictive contributions within a fitted model. It does not establish that changing a feature would causally change population growth, particularly in a panel with correlated socioeconomic variables and potential reverse causality.",
"Model-selection uncertainty. Hyperparameters are deliberately pre-specified to avoid overfitting the small outer period. A larger panel would permit nested temporal tuning, country-holdout evaluation, and systematic comparison of alternative residual-correction learners.",
"Forecast-superiority uncertainty. Although DPC-GB lowers aggregate error, the country-cluster bootstrap intervals include zero. Larger samples and external validation are required before claiming stable superiority across countries.",
"Uncertainty model. Empirical Monte Carlo residual resampling assumes that historical rolling forecast errors are informative about future error distributions. It does not fully model heteroskedasticity, regime changes, or country-specific tail risk. Future work could compare quantile boosting, conformal prediction, Bayesian residual models, and regime-dependent simulation.",
"Data provenance. The reproducibility package regenerates all analyses from the supplied merged analytical file. It cannot reproduce upstream source extraction and merging because the original agency-level raw extracts and merge scripts were not supplied. Future releases should archive those provenance layers when licensing permits."
]
for b in limitations:add_bullet(doc,b)

# 7 Conclusion
add_heading(doc,'7. Conclusion',1)
for t in [
"This study develops an explainable, probabilistic, and benchmark-aware approach to one-year-ahead population-growth forecasting. The proposed DPC-GB model starts from the strongest simple forecast—persistence—and uses gradient boosting to learn only the departure from that anchor. In an expanding-window cross-country evaluation for 2016-2020, the model lowers RMSE by 6.55% and MAE by 5.84% relative to persistence, while DPC-XGBoost provides a qualitatively consistent robustness result. The cluster bootstrap indicates that these improvements remain uncertain in the modest country sample, so the evidence is best characterized as promising rather than definitive.",
"The model's explanatory layer shows that demographic momentum is the dominant source of short-run correction, with unemployment changes, GDP changes, renewable energy, and emissions contributing additional signal. A structural-only analysis reveals predictive information in hospital capacity, fertility, renewable-energy share, unemployment, GDP per capita, freshwater resources, and health expenditure, but it also demonstrates that structural levels cannot replace recent demographic history for short-horizon accuracy.",
"Finally, empirical Monte Carlo simulation provides probabilities of negative population growth and prediction intervals rather than only point forecasts. This probabilistic layer is especially useful for risk-oriented decisions, although its high discrimination in the present sample should be externally validated. Overall, the evidence favors a forecasting philosophy in which strong naive benchmarks, machine-learning corrections, out-of-sample explanations, and explicit uncertainty are designed together rather than added as separate afterthoughts."
]: add_p(doc,t)

# Data/code availability
add_heading(doc,'Data and Code Availability',1)
add_p(doc,"The manuscript is accompanied by a reproducibility package containing the researcher-supplied merged analytical data and data dictionary, the processed dynamic panel, the complete Python analysis script, fixed environment information, SHA-256 checksums, all numerical result tables, and all figures. Running code/run_analysis.py from the package root reproduces the processed panel, rolling-origin forecasts, SHAP summaries, Monte Carlo outputs, robustness tests, figures, environment record, and checksums. The package reproduces the analysis from the merged analytical file; it does not recreate the upstream extraction and merging of the original agency datasets because those source-level extracts and merge scripts were not included in the supplied materials.")
add_heading(doc,'Research Ethics',1)
add_p(doc,"The study uses country-level secondary aggregate data and does not involve identifiable human participants, intervention, or individual-level personal data. The blinded manuscript therefore does not require participant consent or human-subject recruitment procedures.")

# References
add_heading(doc,'References',1)
refs=[
"Azose, J. J., Ševčíková, H., & Raftery, A. E. (2016). Probabilistic population projections with migration uncertainty. Proceedings of the National Academy of Sciences, 113(23), 6460-6465. https://doi.org/10.1073/pnas.1606119113",
"Bergmeir, C., Hyndman, R. J., & Koo, B. (2018). A note on the validity of cross-validation for evaluating autoregressive time series prediction. Computational Statistics & Data Analysis, 120, 70-83. https://doi.org/10.1016/j.csda.2017.11.003",
"Breiman, L. (2001). Random forests. Machine Learning, 45, 5-32. https://doi.org/10.1023/A:1010933404324",
"Brier, G. W. (1950). Verification of forecasts expressed in terms of probability. Monthly Weather Review, 78(1), 1-3.",
"Chen, T., & Guestrin, C. (2016). XGBoost: A scalable tree boosting system. Proceedings of the 22nd ACM SIGKDD International Conference on Knowledge Discovery and Data Mining, 785-794. https://doi.org/10.1145/2939672.2939785",
"Cortes, C., & Vapnik, V. (1995). Support-vector networks. Machine Learning, 20, 273-297. https://doi.org/10.1007/BF00994018",
"Friedman, J. H. (2001). Greedy function approximation: A gradient boosting machine. The Annals of Statistics, 29(5), 1189-1232. https://doi.org/10.1214/aos/1013203451",
"Geurts, P., Ernst, D., & Wehenkel, L. (2006). Extremely randomized trees. Machine Learning, 63, 3-42. https://doi.org/10.1007/s10994-006-6226-1",
"Gneiting, T., & Raftery, A. E. (2007). Strictly proper scoring rules, prediction, and estimation. Journal of the American Statistical Association, 102(477), 359-378. https://doi.org/10.1198/016214506000001437",
"Hyndman, R. J., & Koehler, A. B. (2006). Another look at measures of forecast accuracy. International Journal of Forecasting, 22(4), 679-688. https://doi.org/10.1016/j.ijforecast.2006.03.001",
"Ke, G., Meng, Q., Finley, T., Wang, T., Chen, W., Ma, W., Ye, Q., & Liu, T.-Y. (2017). LightGBM: A highly efficient gradient boosting decision tree. Advances in Neural Information Processing Systems, 30.",
"Lee, R. D., & Tuljapurkar, S. (1994). Stochastic population forecasts for the United States: Beyond high, medium, and low. Journal of the American Statistical Association, 89(428), 1175-1189. https://doi.org/10.1080/01621459.1994.10476857",
"Lundberg, S. M., & Lee, S.-I. (2017). A unified approach to interpreting model predictions. Advances in Neural Information Processing Systems, 30, 4765-4774.",
"Prokhorenkova, L., Gusev, G., Vorobev, A., Dorogush, A. V., & Gulin, A. (2018). CatBoost: Unbiased boosting with categorical features. Advances in Neural Information Processing Systems, 31.",
"Raftery, A. E., Alkema, L., & Gerland, P. (2014). Bayesian population projections for the United Nations. Statistical Science, 29(1), 58-68. https://doi.org/10.1214/13-STS419",
"Raftery, A. E., Li, N., Ševčíková, H., Gerland, P., & Heilig, G. K. (2012). Bayesian probabilistic population projections for all countries. Proceedings of the National Academy of Sciences, 109(35), 13915-13921. https://doi.org/10.1073/pnas.1211452109",
"Şahinarslan, F. V., Tekin, A. T., & Çebi, F. (2021). Application of machine learning algorithms for population forecasting. International Journal of Data Science, 6(4), 257-270. https://doi.org/10.1504/IJDS.2021.122770",
"Wang, J., Ma, S., Lv, Q., & Li, Q. (2025). Demographic forecast modelling using SSA-XGBoost for smart population management based on multi-sources data. PLOS ONE, 20(6), e0320298. https://doi.org/10.1371/journal.pone.0320298"
]
for ref in refs:
    p=doc.add_paragraph(); p.paragraph_format.left_indent=Cm(0.7); p.paragraph_format.first_line_indent=Cm(-0.7); p.paragraph_format.space_after=Pt(3); p.paragraph_format.line_spacing=1.0
    r=p.add_run(ref); set_run_font(r,size=9.5)

# Appendices
add_heading(doc,'Appendix A. Sample Construction and Reproducibility Summary',1)
summary_rows=[
('Initial documented international-statistics sample','4,616 country-year observations, 2000-2020'),
('Complete-case analytical file','672 observations, 47 countries'),
('Dynamic consecutive panel','522 observations, 45 countries'),
('Outer test period','2016-2020'),
('Outer out-of-sample predictions','167'),
('Monte Carlo draws','10,000 per forecast'),
('Country-cluster bootstrap','10,000 replicates'),
('Random seed','20260817')]
add_table(doc,['Item','Value'],summary_rows,widths=[3.0,3.0],font_size=8.5,caption='Table A1. Analysis sample and reproducibility settings')

add_heading(doc,'Appendix B. Fixed Model Specifications',1)
hyp_rows=[
('OLS','Standardized predictors','LinearRegression'),
('Ridge','Standardized predictors','alpha=1.0'),
('Elastic Net','Standardized predictors','alpha=0.01; l1_ratio=0.5; max_iter=10,000'),
('SVR-RBF','Standardized predictors','C=10; epsilon=0.1; gamma=scale'),
('Random Forest','Direct level forecast','300 trees; min_leaf=2; max_features=0.8'),
('Extra Trees','Direct level forecast','300 trees; min_leaf=2; max_features=0.8'),
('Gradient Boosting','Direct level forecast','150 stages; depth=2; lr=0.03; Huber loss'),
('HistGradientBoosting','Direct level forecast','200 iterations; max_leaf_nodes=15; l2=1; lr=0.05'),
('XGBoost','Direct level forecast','150 trees; depth=2; lr=0.03; subsample=0.8; colsample=0.8; lambda=2'),
('LightGBM','Direct level forecast','200 trees; num_leaves=15; lr=0.03; subsample=0.8; colsample=0.8'),
('CatBoost','Direct level forecast','180 iterations; depth=4; lr=0.03'),
('DPC-GB','Correction forecast','80 stages; depth=2; lr=0.05; Huber loss'),
('DPC-XGBoost','Correction forecast','150 trees; depth=2; lr=0.03; subsample=0.8; colsample=0.8; lambda=2')]
add_table(doc,['Model','Role','Fixed configuration'],hyp_rows,widths=[1.25,1.35,3.55],font_size=7.6,caption='Table B1. Prespecified modeling configurations',note='Exact software arguments are in code/run_analysis.py. Random seed is 20260817; key boosting implementations are constrained to deterministic/single-thread execution where practical.')

add_heading(doc,'Appendix C. Leakage Audit: Highest Absolute Correlations with Current Population Growth',1)
rows=[]
for _,r in leak.head(12).iterrows():
    rows.append((r.Feature,f"{r.CorrelationWithCurrentPopulationGrowth:+.4f}",'Yes' if bool(r.ExcludedFromMain) else 'No'))
add_table(doc,['Feature','Correlation','Excluded from main model'],rows,widths=[3.0,1.3,1.7],font_size=8.4,caption='Table C1. Feature-engineering audit',note='Current PopulationGrowth appears with correlation 1 by construction because it is the persistence anchor. d_FreshwaterPC is excluded due to its near-mechanical relationship with contemporaneous population change.')

add_heading(doc,'Appendix D. Reproduction Checklist',1)
for b in [
"Create a Python 3.13 environment and install the versions in requirements.txt.",
"Run python code/run_analysis.py from the package root.",
"Confirm that outputs/tables/model_performance.csv reports DPC-GB RMSE approximately 0.204835.",
"Confirm that outputs/tables/probability_metrics.csv reports Brier score approximately 0.015926 and 95% interval coverage approximately 0.970060.",
"Verify package integrity with CHECKSUMS_SHA256.txt after reproduction if files have not intentionally changed.",
"Treat the package as reproducing the analysis from the merged analytical dataset; upstream agency-data extraction is outside the provided provenance."
]: add_bullet(doc,b)

# Final formatting fixes: widow/orphan control, font in all paragraphs/tables
for p in doc.paragraphs:
    p.paragraph_format.widow_control=True
for table in doc.tables:
    for row in table.rows:
        for cell in row.cells:
            for p in cell.paragraphs:
                p.paragraph_format.widow_control=True

# Core properties
props=doc.core_properties
props.title='Explainable and Probabilistic Forecasting of Annual Population Growth: A Dynamic Persistence-Correction Machine-Learning Framework'
props.subject='Cross-country one-year-ahead population-growth forecasting with DPC-GB, SHAP, and Monte Carlo uncertainty'
props.author='Blinded for Review'
props.keywords='population growth, machine learning, SHAP, Monte Carlo, probabilistic forecasting, gradient boosting'

OUT.parent.mkdir(parents=True,exist_ok=True)
doc.save(OUT)
print(OUT)
