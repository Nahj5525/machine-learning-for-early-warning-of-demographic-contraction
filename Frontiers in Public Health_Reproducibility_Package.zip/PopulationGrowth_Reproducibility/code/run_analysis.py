#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""End-to-end reproducibility script for one-year-ahead population-growth forecasting.

The analysis intentionally uses a compact, pre-specified set of hyperparameters because the
country-year panel is modest in size. All models are evaluated with the same expanding-window
rolling-origin test years (2016-2020). No future observations enter a model before their test year.

Proposed hybrid: Dynamic Persistence-Correction Gradient Boosting (DPC-GB)
  forecast_{i,t+1} = PopulationGrowth_{i,t} + GB(X_{i,t}, lags, changes),
where GB is trained to predict PopulationGrowth_{i,t+1} - PopulationGrowth_{i,t}.

SHAP values are calculated for the correction component on out-of-sample test observations.
Monte Carlo probabilities use 10,000 empirical draws from historical rolling-OOS residuals.
"""
from __future__ import annotations
import os, sys, json, hashlib, platform, warnings
from pathlib import Path
warnings.filterwarnings('ignore')
os.environ.setdefault('OMP_NUM_THREADS','1'); os.environ.setdefault('MKL_NUM_THREADS','1')

import numpy as np, pandas as pd, scipy
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
import sklearn
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score, brier_score_loss, roc_auc_score, average_precision_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, Ridge, ElasticNet
from sklearn.svm import SVR
from sklearn.ensemble import RandomForestRegressor, ExtraTreesRegressor, GradientBoostingRegressor, HistGradientBoostingRegressor
from xgboost import XGBRegressor
import xgboost
from lightgbm import LGBMRegressor
import lightgbm
from catboost import CatBoostRegressor
import catboost
import shap

SEED=20260817; N_MC=10000; N_BOOT=10000; OUTER_YEARS=[2016,2017,2018,2019,2020]
ROOT=Path(__file__).resolve().parents[1]; RAW=ROOT/'data'/'raw'; PROC=ROOT/'data'/'processed'; TAB=ROOT/'outputs'/'tables'; FIG=ROOT/'outputs'/'figures'
for d in [PROC,TAB,FIG]: d.mkdir(parents=True,exist_ok=True)
DATA=RAW/'보건데이터(인구 증가율)_20260815.csv'; DICT=RAW/'인구 증가율(결과).csv'

PREDICTORS=['FertilityRate','HealthExpPC','HospitalBeds','DPTImmunization','GDPpc','GDPWorldShare','CPIGrowth','GDPDeflator','PrimaryExpGDP','TertiaryExpGDP','YouthUnempRate','UnempRate','CivilSocietyIndex','EqualProtection','FreedomExpression','AccessJustice','RenewEnergyShare','FreshwaterPC','GHGEmissions','AirPollutionExposure']
DOMAINS={
 'Health':['FertilityRate','HealthExpPC','HospitalBeds','DPTImmunization'],
 'Economy':['GDPpc','GDPWorldShare','CPIGrowth','GDPDeflator'],
 'Social':['PrimaryExpGDP','TertiaryExpGDP','YouthUnempRate','UnempRate'],
 'Politics':['CivilSocietyIndex','EqualProtection','FreedomExpression','AccessJustice'],
 'Environment':['RenewEnergyShare','FreshwaterPC','GHGEmissions','AirPollutionExposure']}

def rmse(y,p): return float(np.sqrt(mean_squared_error(y,p)))
def met(y,p): return {'N':int(len(y)),'MAE':float(mean_absolute_error(y,p)),'RMSE':rmse(y,p),'R2':float(r2_score(y,p))}

def build_panel():
 df=pd.read_csv(DATA,encoding='cp949').sort_values(['Country','Year']).reset_index(drop=True)
 g=df.groupby('Country',group_keys=False)
 df['PrevYear']=g.Year.shift(1); df['PG_lag2']=g.PopulationGrowth.shift(1); df['d_PopulationGrowth']=df.PopulationGrowth-df.PG_lag2
 for c in PREDICTORS: df['d_'+c]=df[c]-g[c].shift(1)
 df['TargetYear']=g.Year.shift(-1); df['Target']=g.PopulationGrowth.shift(-1)
 p=df[(df.PrevYear==df.Year-1)&(df.TargetYear==df.Year+1)].copy(); p['TargetYear']=p.TargetYear.astype(int); p['DeltaTarget']=p.Target-p.PopulationGrowth
 # d_FreshwaterPC is excluded because the per-capita denominator mechanically embeds population change.
 features=['PopulationGrowth','PG_lag2','d_PopulationGrowth']+PREDICTORS+['d_'+c for c in PREDICTORS if c!='FreshwaterPC']
 p.to_csv(PROC/'modeling_panel.csv',index=False,encoding='utf-8-sig')
 return df,p,features

def models():
 return {
  'OLS':Pipeline([('scale',StandardScaler()),('model',LinearRegression())]),
  'Ridge':Pipeline([('scale',StandardScaler()),('model',Ridge(alpha=1.0))]),
  'ElasticNet':Pipeline([('scale',StandardScaler()),('model',ElasticNet(alpha=.01,l1_ratio=.5,max_iter=10000,random_state=SEED))]),
  'SVR-RBF':Pipeline([('scale',StandardScaler()),('model',SVR(C=10,epsilon=.1,gamma='scale'))]),
  'RandomForest':RandomForestRegressor(n_estimators=300,min_samples_leaf=2,max_features=.8,random_state=SEED,n_jobs=-1),
  'ExtraTrees':ExtraTreesRegressor(n_estimators=300,min_samples_leaf=2,max_features=.8,random_state=SEED,n_jobs=-1),
  'GradientBoosting':GradientBoostingRegressor(n_estimators=150,max_depth=2,learning_rate=.03,loss='huber',random_state=SEED),
  'HistGradientBoosting':HistGradientBoostingRegressor(max_iter=200,max_leaf_nodes=15,l2_regularization=1.0,learning_rate=.05,random_state=SEED),
  'XGBoost':XGBRegressor(n_estimators=150,max_depth=2,learning_rate=.03,subsample=.8,colsample_bytree=.8,min_child_weight=2,reg_lambda=2,objective='reg:squarederror',random_state=SEED,n_jobs=1),
  'LightGBM':LGBMRegressor(n_estimators=200,num_leaves=15,learning_rate=.03,subsample=.8,colsample_bytree=.8,reg_lambda=1,random_state=SEED,verbosity=-1,n_jobs=1),
  'CatBoost':CatBoostRegressor(iterations=180,depth=4,learning_rate=.03,loss_function='RMSE',verbose=False,random_seed=SEED,allow_writing_files=False,thread_count=1),
 }

def dpc_gb(): return GradientBoostingRegressor(n_estimators=80,max_depth=2,learning_rate=.05,loss='huber',random_state=SEED)
def dpc_xgb(): return XGBRegressor(n_estimators=150,max_depth=2,learning_rate=.03,subsample=.8,colsample_bytree=.8,min_child_weight=2,reg_lambda=2,objective='reg:squarederror',random_state=SEED,n_jobs=1)

def hist_residuals(train,features,template):
 res=[]
 for vy in sorted(train.TargetYear.unique()):
  tr=train[train.TargetYear<vy]; va=train[train.TargetYear==vy]
  if len(tr)<80: continue
  m=template.__class__(**template.get_params()) if not isinstance(template,Pipeline) else None
  # DPC template here is sklearn GradientBoostingRegressor.
  m.fit(tr[features],tr.DeltaTarget); pred=va.PopulationGrowth.to_numpy()+m.predict(va[features]); res.extend((va.Target.to_numpy()-pred).tolist())
 return np.asarray(res,float)

def run(df,panel,features):
 preds=[]; folds=[]; shap_long=[]; mc=[]; rng=np.random.default_rng(SEED)
 for oy in OUTER_YEARS:
  tr=panel[panel.TargetYear<oy]; te=panel[panel.TargetYear==oy]
  # persistence
  pp=te.PopulationGrowth.to_numpy()
  for j,(_,r) in enumerate(te.iterrows()): preds.append({'Country':r.Country,'TargetYear':oy,'y_true':r.Target,'Model':'Persistence','Prediction':float(pp[j])})
  folds.append({'Model':'Persistence','TargetYear':oy,**met(te.Target,pp)})
  # direct benchmarks
  for name,m in models().items():
   m.fit(tr[features],tr.Target); pr=m.predict(te[features])
   for j,(_,r) in enumerate(te.iterrows()): preds.append({'Country':r.Country,'TargetYear':oy,'y_true':r.Target,'Model':name,'Prediction':float(pr[j])})
   folds.append({'Model':name,'TargetYear':oy,**met(te.Target,pr)})
  # DPC-GB proposed
  hg=dpc_gb(); hg.fit(tr[features],tr.DeltaTarget); corr=hg.predict(te[features]); hp=pp+corr
  for j,(_,r) in enumerate(te.iterrows()): preds.append({'Country':r.Country,'TargetYear':oy,'y_true':r.Target,'Model':'DPC-GB (proposed)','Prediction':float(hp[j])})
  folds.append({'Model':'DPC-GB (proposed)','TargetYear':oy,**met(te.Target,hp)})
  # DPC-XGB robustness
  hx=dpc_xgb(); hx.fit(tr[features],tr.DeltaTarget); xp=pp+hx.predict(te[features])
  for j,(_,r) in enumerate(te.iterrows()): preds.append({'Country':r.Country,'TargetYear':oy,'y_true':r.Target,'Model':'DPC-XGBoost','Prediction':float(xp[j])})
  folds.append({'Model':'DPC-XGBoost','TargetYear':oy,**met(te.Target,xp)})
  # OOS SHAP of correction component
  ex=shap.TreeExplainer(hg); sv=np.asarray(ex.shap_values(te[features]));
  for i,(_,r) in enumerate(te.iterrows()):
   for k,f in enumerate(features): shap_long.append({'Country':r.Country,'TargetYear':oy,'Feature':f,'SHAP':float(sv[i,k])})
  # empirical residual Monte Carlo from earlier rolling OOS residuals only
  resid=hist_residuals(tr,features,dpc_gb())
  if len(resid)<20: resid=(tr.Target-tr.PopulationGrowth).to_numpy()
  for j,(_,r) in enumerate(te.iterrows()):
   sim=hp[j]+rng.choice(resid,N_MC,replace=True)
   mc.append({'Country':r.Country,'TargetYear':oy,'y_true':float(r.Target),'PointForecast':float(hp[j]),'P_negative':float(np.mean(sim<0)),
              'PI90_L':float(np.quantile(sim,.05)),'PI90_U':float(np.quantile(sim,.95)),'PI95_L':float(np.quantile(sim,.025)),'PI95_U':float(np.quantile(sim,.975)),'ResidualPoolN':len(resid)})
 preds=pd.DataFrame(preds); folds=pd.DataFrame(folds); sh=pd.DataFrame(shap_long); mc=pd.DataFrame(mc)
 perf=pd.DataFrame([{'Model':m,**met(z.y_true,z.Prediction)} for m,z in preds.groupby('Model')]).sort_values(['RMSE','MAE']).reset_index(drop=True)
 p0=perf[perf.Model=='Persistence'].iloc[0]; perf['MAE_vs_Persistence']=perf.MAE/p0.MAE;perf['RMSE_vs_Persistence']=perf.RMSE/p0.RMSE;perf['RMSE_Improvement_pct']=100*(1-perf.RMSE_vs_Persistence)
 shsum=(sh.assign(AbsSHAP=sh.SHAP.abs()).groupby('Feature',as_index=False).agg(MeanAbsSHAP=('AbsSHAP','mean'),MeanSHAP=('SHAP','mean'),N=('SHAP','size')).sort_values('MeanAbsSHAP',ascending=False))
 def dom(f):
  if f in ['PopulationGrowth','PG_lag2','d_PopulationGrowth']: return 'Demographic momentum'
  b=f[2:] if f.startswith('d_') else f
  for d,cols in DOMAINS.items():
   if b in cols:return d
  return 'Other'
 sh['Domain']=sh.Feature.map(dom)
 dsum=(sh.assign(AbsSHAP=sh.SHAP.abs()).groupby(['Country','TargetYear','Domain'],as_index=False).AbsSHAP.sum().groupby('Domain',as_index=False).agg(MeanSumAbsSHAP=('AbsSHAP','mean')).sort_values('MeanSumAbsSHAP',ascending=False))
 # Structural-only SHAP using level predictors, fixed GBDT
 ss=[]; sp=[]
 for oy in OUTER_YEARS:
  tr=panel[panel.TargetYear<oy];te=panel[panel.TargetYear==oy];m=GradientBoostingRegressor(n_estimators=150,max_depth=2,learning_rate=.03,loss='huber',random_state=SEED);m.fit(tr[PREDICTORS],tr.Target);pr=m.predict(te[PREDICTORS]);ex=shap.TreeExplainer(m);sv=np.asarray(ex.shap_values(te[PREDICTORS]))
  for j,(_,r) in enumerate(te.iterrows()): sp.append({'Country':r.Country,'TargetYear':oy,'y_true':r.Target,'Prediction':float(pr[j])})
  for i,(_,r) in enumerate(te.iterrows()):
   for k,f in enumerate(PREDICTORS):ss.append({'Country':r.Country,'TargetYear':oy,'Feature':f,'SHAP':float(sv[i,k])})
 ss=pd.DataFrame(ss); ssum=(ss.assign(AbsSHAP=ss.SHAP.abs()).groupby('Feature',as_index=False).agg(MeanAbsSHAP=('AbsSHAP','mean'),MeanSHAP=('SHAP','mean'),N=('SHAP','size')).sort_values('MeanAbsSHAP',ascending=False));sp=pd.DataFrame(sp)
 # Probability metrics
 ev=(mc.y_true<0).astype(int); prob=mc.P_negative
 pm=pd.DataFrame([{'N':len(mc),'NegativeEvents':int(ev.sum()),'BrierScore':float(brier_score_loss(ev,prob)),'ROC_AUC':float(roc_auc_score(ev,prob)),'AveragePrecision':float(average_precision_score(ev,prob)),'PI90_Coverage':float(np.mean((mc.y_true>=mc.PI90_L)&(mc.y_true<=mc.PI90_U))),'PI95_Coverage':float(np.mean((mc.y_true>=mc.PI95_L)&(mc.y_true<=mc.PI95_U))),'Mean_PI90_Width':float(np.mean(mc.PI90_U-mc.PI90_L)),'Mean_PI95_Width':float(np.mean(mc.PI95_U-mc.PI95_L))}])
 # cluster bootstrap
 w=preds[preds.Model.isin(['Persistence','DPC-GB (proposed)'])].pivot_table(index=['Country','TargetYear','y_true'],columns='Model',values='Prediction').reset_index();cs=w.Country.unique();rg=np.random.default_rng(SEED+1)
 # Efficient country-cluster bootstrap from cluster sufficient statistics.
 stats=[]
 for c in cs:
  z=w[w.Country==c]; y=z.y_true.to_numpy(); p=z.Persistence.to_numpy(); h=z['DPC-GB (proposed)'].to_numpy()
  stats.append((len(z),np.sum((y-p)**2),np.sum((y-h)**2),np.sum(np.abs(y-p)),np.sum(np.abs(y-h))))
 stats=np.asarray(stats,float); draws=rg.integers(0,len(cs),size=(N_BOOT,len(cs)))
 n=stats[draws,0].sum(axis=1); ssep=stats[draws,1].sum(axis=1); sseh=stats[draws,2].sum(axis=1); saep=stats[draws,3].sum(axis=1); saeh=stats[draws,4].sum(axis=1)
 br=np.sqrt(ssep/n)-np.sqrt(sseh/n); ba=saep/n-saeh/n
 boot=pd.DataFrame([{'Metric':'RMSE improvement (Persistence - DPC-GB)','Estimate':rmse(w.y_true,w.Persistence)-rmse(w.y_true,w['DPC-GB (proposed)']),'CI2.5':np.quantile(br,.025),'CI97.5':np.quantile(br,.975),'OneSided_p':np.mean(br<=0),'BootstrapReplicates':N_BOOT},{'Metric':'MAE improvement (Persistence - DPC-GB)','Estimate':mean_absolute_error(w.y_true,w.Persistence)-mean_absolute_error(w.y_true,w['DPC-GB (proposed)']),'CI2.5':np.quantile(ba,.025),'CI97.5':np.quantile(ba,.975),'OneSided_p':np.mean(ba<=0),'BootstrapReplicates':N_BOOT}])
 # Robustness
 rob=[]
 for label,sub in [('2016-2020',preds),('2016-2019 (exclude 2020)',preds[preds.TargetYear<=2019])]:
  for m in ['Persistence','GradientBoosting','XGBoost','DPC-XGBoost','DPC-GB (proposed)']:
   z=sub[sub.Model==m];rob.append({'Sample':label,'Model':m,**met(z.y_true,z.Prediction)})
 rob.append({'Sample':'2016-2020','Model':'Structural-only GradientBoosting',**met(sp.y_true,sp.Prediction)});rob=pd.DataFrame(rob)
 # Leakage audit
 aud=[]
 for f in features+['d_FreshwaterPC']:
  r=1.0 if f=='PopulationGrowth' else float(panel[['PopulationGrowth',f]].corr().iloc[0,1]);aud.append({'Feature':f,'CorrelationWithCurrentPopulationGrowth':r,'AbsCorrelation':abs(r),'ExcludedFromMain':f=='d_FreshwaterPC'})
 aud=pd.DataFrame(aud).sort_values('AbsCorrelation',ascending=False)
 # Save
 for name,obj in [('oos_predictions',preds),('yearly_model_performance',folds),('model_performance',perf),('oos_shap_long',sh),('shap_feature_summary',shsum),('shap_domain_summary',dsum),('structural_shap_summary',ssum),('monte_carlo_predictions',mc),('probability_metrics',pm),('country_cluster_bootstrap',boot),('robustness',rob),('leakage_audit',aud)]: obj.to_csv(TAB/(name+'.csv'),index=False,encoding='utf-8-sig')
 return preds,folds,perf,shsum,dsum,ssum,mc,pm,boot,rob,aud

def descriptives(df,p):
 d=df[['PopulationGrowth']+PREDICTORS].agg(['count','mean','std','min','median','max']).T.reset_index().rename(columns={'index':'Variable'});d.to_csv(TAB/'descriptive_statistics.csv',index=False,encoding='utf-8-sig')
 s=pd.DataFrame([['Raw analytical complete-case observations',len(df)],['Countries in complete-case file',df.Country.nunique()],['Raw year range',f'{df.Year.min()}-{df.Year.max()}'],['Dynamic consecutive t-1,t,t+1 observations',len(p)],['Countries in dynamic panel',p.Country.nunique()],['Outer OOS target years','2016-2020'],['Outer OOS observations',int(p.TargetYear.isin(OUTER_YEARS).sum())],['Monte Carlo draws per forecast',N_MC],['Country-cluster bootstrap replicates',N_BOOT],['Random seed',SEED]],columns=['Item','Value']);s.to_csv(TAB/'sample_summary.csv',index=False,encoding='utf-8-sig')
 try:pd.read_csv(DICT,encoding='cp949',header=None).to_csv(TAB/'user_data_dictionary.csv',index=False,header=False,encoding='utf-8-sig')
 except:pass
 return d,s

def figs(perf,folds,shsum,dsum,mc,preds):
 plt.rcParams.update({'font.size':9,'savefig.dpi':220})
 z=perf.sort_values('RMSE');fig,ax=plt.subplots(figsize=(7.5,5.6));ax.barh(z.Model,z.RMSE);ax.set_xlabel('Rolling-origin OOS RMSE');ax.set_title('One-year-ahead population-growth forecast comparison');ax.grid(axis='x',alpha=.25);fig.tight_layout();fig.savefig(FIG/'fig1_model_rmse.png',bbox_inches='tight');plt.close(fig)
 fig,ax=plt.subplots(figsize=(7.2,4.7));
 for m in ['Persistence','GradientBoosting','XGBoost','DPC-GB (proposed)']:
  z=folds[folds.Model==m].sort_values('TargetYear');ax.plot(z.TargetYear,z.RMSE,marker='o',label=m)
 ax.set_xticks(OUTER_YEARS);ax.set_xlabel('Target year');ax.set_ylabel('RMSE');ax.set_title('Rolling-origin RMSE by target year');ax.grid(alpha=.25);ax.legend(fontsize=8);fig.tight_layout();fig.savefig(FIG/'fig2_yearly_rmse.png',bbox_inches='tight');plt.close(fig)
 z=shsum.head(15).sort_values('MeanAbsSHAP');fig,ax=plt.subplots(figsize=(7.4,5.8));ax.barh(z.Feature,z.MeanAbsSHAP);ax.set_xlabel('Mean |SHAP| on correction component');ax.set_title('OOS SHAP importance: proposed DPC-GB');ax.grid(axis='x',alpha=.25);fig.tight_layout();fig.savefig(FIG/'fig3_shap_features.png',bbox_inches='tight');plt.close(fig)
 z=dsum.sort_values('MeanSumAbsSHAP');fig,ax=plt.subplots(figsize=(6.8,4.2));ax.barh(z.Domain,z.MeanSumAbsSHAP);ax.set_xlabel('Mean summed |SHAP|');ax.set_title('Grouped OOS SHAP importance by domain');ax.grid(axis='x',alpha=.25);fig.tight_layout();fig.savefig(FIG/'fig4_shap_domains.png',bbox_inches='tight');plt.close(fig)
 probs=mc.P_negative.to_numpy();ev=(mc.y_true<0).astype(int).to_numpy();bins=np.array([0,.05,.15,.35,.65,.85,.95,1.000001]);xs=[];ys=[];ns=[]
 for lo,hi in zip(bins[:-1],bins[1:]):
  q=(probs>=lo)&(probs<hi)
  if q.sum():xs.append(probs[q].mean());ys.append(ev[q].mean());ns.append(q.sum())
 fig,ax=plt.subplots(figsize=(5.4,5.1));ax.plot([0,1],[0,1],'--');ax.scatter(xs,ys,s=[max(35,n*5) for n in ns]);ax.set_xlim(-.03,1.03);ax.set_ylim(-.03,1.03);ax.set_xlabel('Mean predicted P(growth < 0)');ax.set_ylabel('Observed negative-growth frequency');ax.set_title('Monte Carlo probability calibration');ax.grid(alpha=.25);fig.tight_layout();fig.savefig(FIG/'fig5_probability_calibration.png',bbox_inches='tight');plt.close(fig)
 z=mc[mc.TargetYear==2020].sort_values('P_negative',ascending=False).head(12).sort_values('P_negative');fig,ax=plt.subplots(figsize=(7,5));ax.barh(z.Country,z.P_negative);ax.set_xlim(0,1);ax.set_xlabel('P(PopulationGrowth < 0)');ax.set_title('Highest predicted population-decline probabilities: 2020 OOS');ax.grid(axis='x',alpha=.25);fig.tight_layout();fig.savefig(FIG/'fig6_2020_decline_risk.png',bbox_inches='tight');plt.close(fig)
 z=preds[preds.Model=='DPC-GB (proposed)'];fig,ax=plt.subplots(figsize=(5.5,5.1));ax.scatter(z.y_true,z.Prediction,alpha=.7);lo=min(z.y_true.min(),z.Prediction.min());hi=max(z.y_true.max(),z.Prediction.max());ax.plot([lo,hi],[lo,hi],'--');ax.set_xlabel('Observed population growth');ax.set_ylabel('DPC-GB forecast');ax.set_title('Observed versus OOS forecasts');ax.grid(alpha=.25);fig.tight_layout();fig.savefig(FIG/'fig7_predicted_vs_observed.png',bbox_inches='tight');plt.close(fig)

def checksums():
 rows=[]
 for p in sorted(ROOT.rglob('*')):
  if p.is_file() and p.name!='CHECKSUMS_SHA256.txt':
   h=hashlib.sha256(p.read_bytes()).hexdigest();rows.append((str(p.relative_to(ROOT)),h))
 (ROOT/'CHECKSUMS_SHA256.txt').write_text(''.join(f'{h}  {r}\n' for r,h in rows),encoding='utf-8')

def main():
 np.random.seed(SEED);df,p,features=build_panel();d,s=descriptives(df,p);preds,folds,perf,shsum,dsum,ssum,mc,pm,boot,rob,aud=run(df,p,features);figs(perf,folds,shsum,dsum,mc,preds)
 env={'python':sys.version,'platform':platform.platform(),'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__,'sklearn':sklearn.__version__,'xgboost':xgboost.__version__,'lightgbm':lightgbm.__version__,'catboost':catboost.__version__,'shap':shap.__version__,'matplotlib':matplotlib.__version__,'seed':SEED,'N_MC':N_MC,'N_BOOT':N_BOOT};(ROOT/'environment.json').write_text(json.dumps(env,ensure_ascii=False,indent=2),encoding='utf-8');checksums()
 print('=== SAMPLE ===');print(s.to_string(index=False));print('\n=== PERFORMANCE ===');print(perf.to_string(index=False));print('\n=== PROBABILITY ===');print(pm.to_string(index=False));print('\n=== BOOTSTRAP ===');print(boot.to_string(index=False));print('\n=== TOP SHAP ===');print(shsum.head(12).to_string(index=False));print('\n=== DOMAIN SHAP ===');print(dsum.to_string(index=False));print('\n=== LEAKAGE ===');print(aud.head(8).to_string(index=False))
if __name__=='__main__':main()
