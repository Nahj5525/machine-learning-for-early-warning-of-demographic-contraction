# Package Manifest

## Core input data
- `data/raw/보건데이터(인구 증가율)_20260815.csv`
- `data/raw/인구 증가율(결과).csv`

## Code
- `code/run_analysis.py`
- `code/build_manuscript.py`
- `code/run_all.py`

## Processed data
- `data/processed/modeling_panel.csv`

## Main tables
- `outputs/tables/model_performance.csv`
- `outputs/tables/yearly_model_performance.csv`
- `outputs/tables/oos_predictions.csv`
- `outputs/tables/country_cluster_bootstrap.csv`
- `outputs/tables/probability_metrics.csv`
- `outputs/tables/monte_carlo_predictions.csv`
- `outputs/tables/shap_feature_summary.csv`
- `outputs/tables/shap_domain_summary.csv`
- `outputs/tables/structural_shap_summary.csv`
- `outputs/tables/leakage_audit.csv`
- `outputs/tables/robustness.csv`
- `outputs/tables/descriptive_statistics.csv`
- `outputs/tables/sample_summary.csv`

## Figures
- `outputs/figures/fig1_model_rmse.png`
- `outputs/figures/fig2_yearly_rmse.png`
- `outputs/figures/fig3_shap_features.png`
- `outputs/figures/fig4_shap_domains.png`
- `outputs/figures/fig5_probability_calibration.png`
- `outputs/figures/fig6_2020_decline_risk.png`
- `outputs/figures/fig7_predicted_vs_observed.png`

## Manuscript
- `docs/PopulationGrowth_Final_Manuscript.docx`

## Documentation
- `README.md`
- `docs/analysis_protocol.md`
- `docs/references.bib`
- `requirements.txt`
- `environment.json`
- `CHECKSUMS_SHA256.txt`
- `analysis_run.log`
