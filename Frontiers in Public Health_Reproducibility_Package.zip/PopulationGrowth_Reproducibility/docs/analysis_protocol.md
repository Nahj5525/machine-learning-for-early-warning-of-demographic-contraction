# Analysis Protocol

## 1. Research question

Can multidimensional health, economic, social, political/institutional, and environmental information improve one-year-ahead forecasts of national population-growth rates beyond a strong demographic persistence benchmark, and can the resulting forecasts be converted into interpretable probabilities of population decline?

## 2. Unit of analysis and forecast timing

The unit is the country-year. The target is `PopulationGrowth_(i,t+1)`. Predictors are measured at `t`; dynamic features may also use information from `t-1`. This timing prevents same-year predictors from being presented as future forecasts.

## 3. Dynamic panel construction

The supplied complete-case file contains 672 observations from 47 countries over 2000-2020. For the dynamic forecasting panel, an observation is retained only when the same country has consecutive observations at `t-1`, `t`, and `t+1`. This produces 522 modeling observations from 45 countries.

## 4. Features

Base predictors are 20 researcher-defined indicators in five domains:

- Health: FertilityRate, HealthExpPC, HospitalBeds, DPTImmunization.
- Economy: GDPpc, GDPWorldShare, CPIGrowth, GDPDeflator.
- Social: PrimaryExpGDP, TertiaryExpGDP, YouthUnempRate, UnempRate.
- Politics/institutions: CivilSocietyIndex, EqualProtection, FreedomExpression, AccessJustice.
- Environment: RenewEnergyShare, FreshwaterPC, GHGEmissions, AirPollutionExposure.

The main dynamic model adds current PopulationGrowth, its second lag (`PG_lag2`), the most recent change in PopulationGrowth, and first differences of predictors. `d_FreshwaterPC` is excluded following a leakage/mechanical-denominator audit; the level is retained.

## 5. Validation

Primary evaluation uses an expanding-window rolling-origin design. Target years 2016, 2017, 2018, 2019, and 2020 are each predicted only with observations whose target year is earlier than the corresponding test year. The combined outer test set contains 167 country-year forecasts.

## 6. Benchmark models

- Persistence
- OLS
- Ridge
- Elastic Net
- SVR with radial-basis kernel
- Random Forest
- Extra Trees
- Gradient Boosting
- Histogram Gradient Boosting
- XGBoost
- LightGBM
- CatBoost

Hyperparameters are deliberately compact and pre-specified rather than selected on the outer test years. See `code/run_analysis.py` for exact values.

## 7. Proposed DPC-GB model

Let G(i,t) denote observed population growth at time t. Define the correction target:

`DeltaG(i,t+1) = G(i,t+1) - G(i,t)`.

A gradient-boosting regressor estimates the correction from information available through time t. The final forecast is:

`Ghat(i,t+1) = G(i,t) + DeltaGhat(i,t+1)`.

Thus, the persistence forecast is the anchor and machine learning is responsible only for the nonlinear departure from persistence.

The proposed DPC-GB uses 80 boosting stages, maximum tree depth 2, learning rate 0.05, Huber loss, and random seed 20260817.

A DPC-XGBoost specification is included as a robustness comparison.

## 8. Evaluation metrics

Point forecasts are evaluated using MAE, RMSE, and R-squared. The persistence model is treated as the substantive benchmark because population-growth rates display strong short-run persistence.

## 9. SHAP explainability

Tree SHAP is calculated only on outer out-of-sample observations for the DPC-GB correction component. Because the final DPC-GB forecast equals persistence plus the correction, SHAP values describe features pushing the forecast above or below the persistence anchor.

A second structural-only gradient-boosting model uses only the 20 level predictors. Its SHAP results are reported to distinguish structural predictive signals from the much stronger demographic-momentum information.

SHAP values are descriptive predictive attributions, not causal effects.

## 10. Monte Carlo probability forecasts

For each outer target year, a residual pool is constructed using rolling out-of-sample DPC-GB errors from earlier target years available in the corresponding training sample. Each point forecast receives 10,000 empirical residual draws. The simulations yield:

- probability that `PopulationGrowth < 0`;
- 90% prediction interval;
- 95% prediction interval.

Probability forecasts are assessed with Brier score, ROC-AUC, average precision, interval coverage, and interval width.

## 11. Country-cluster bootstrap

Forecast-error improvement of DPC-GB versus persistence is resampled at the country level using 10,000 bootstrap replicates. The analysis reports the estimated MAE/RMSE improvement, 95% percentile interval, and a one-sided empirical probability that the improvement is non-positive.

## 12. Robustness analyses

- Alternative DPC-XGBoost correction learner.
- Direct machine-learning benchmarks.
- Structural-only model.
- Re-estimation of aggregate forecast performance excluding 2020 as a shock/stress year.

## 13. Interpretation rules used in the manuscript

1. The average DPC-GB improvement is reported as predictive evidence, but not as conventionally statistically significant because the cluster-bootstrap interval includes zero.
2. High decline-probability discrimination is interpreted cautiously because there are only 29 negative-growth events in the outer evaluation set.
3. 2020 is treated as a stress year and not removed from the primary specification.
4. SHAP results are not described as causal determinants.
5. The study forecasts annual growth rates; it does not replace cohort-component population projections by age, sex, fertility, mortality, and migration.
